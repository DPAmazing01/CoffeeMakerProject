package edu.ncsu.csc.CoffeeMaker.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 * Inventory for the coffee maker. Inventory is tied to the database using
 * Hibernate libraries. See InventoryRepository and InventoryService for the
 * other two pieces used for database support.
 *
 *
 * @author Kai Presler-Marshall
 */
@Entity
public class Inventory extends DomainObject {

    /** id for inventory entry */
    @Id
    @GeneratedValue
    private Long                   id;

    /** Ingredients in CoffeeMaker */
    @OneToMany ( cascade = CascadeType.ALL, fetch = FetchType.EAGER )
    private final List<Ingredient> ingredients;

    /**
     * Empty constructor for Hibernate
     */
    public Inventory () {
        this.ingredients = new ArrayList<Ingredient>();
        // Intentionally empty so that Hibernate can instantiate
        // Inventory object.
    }

    /**
     * Returns the ID of the entry in the DB
     *
     * @return long
     */
    @Override
    public Long getId () {
        return id;
    }

    /**
     * Set the ID of the Inventory (Used by Hibernate)
     *
     * @param id
     *            the ID
     */
    public void setId ( final Long id ) {
        this.id = id;
    }

    /**
     * Returns the list of ingredients stored in inventory
     *
     * @return list of ingredients
     */
    public List<Ingredient> getIngredients () {
        return ingredients;
    }

    /**
     *
     * Verify that a user-inputed amount value is a positive integer.
     *
     * @param amount
     *            amount to check
     * @return checked amount
     * @throws IllegalArgumentException
     *             if the parameter isn't a positive integer
     */
    public Integer checkAmount ( final String amount ) throws IllegalArgumentException {
        Integer amt = 0;
        try {
            amt = Integer.parseInt( amount );
        }
        catch ( final NumberFormatException e ) {
            throw new IllegalArgumentException( "Units must be a positive integer" );
        }
        if ( amt < 0 ) {
            throw new IllegalArgumentException( "Units must be a positive integer" );
        }

        return amt;
    }

    /**
     * Returns true if there are enough ingredients to make the beverage.
     *
     * @param r
     *            recipe to check if there are enough ingredients
     * @return true if enough ingredients to make the beverage
     */
    public boolean enoughIngredients ( final Recipe r ) {

        for ( final Ingredient recipeIngr : r.getIngredients() ) {
            for ( final Ingredient invIngr : ingredients ) {
                if ( recipeIngr.getName().equals( invIngr.getName() )
                        && recipeIngr.getAmount() > invIngr.getAmount() ) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Removes the ingredients used to make the specified recipe. Assumes that
     * the user has checked that there are enough ingredients to make
     *
     * @param r
     *            recipe to make
     * @return true if recipe is made.
     */
    public boolean useIngredients ( final Recipe r ) {
        if ( enoughIngredients( r ) ) {
            for ( final Ingredient recipeIngr : r.getIngredients() ) {
                for ( final Ingredient invIngr : ingredients ) {
                    if ( recipeIngr.getName().equals( invIngr.getName() ) ) {
                        invIngr.setAmount( invIngr.getAmount() - recipeIngr.getAmount() );
                    }
                }
            }
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Updates amount for ingredients in the inventory
     *
     * @throws IllegalArgumentException
     *             if the user attempts to add negative amount to the
     *             ingredients
     *
     * @return true if successful, false if not
     */
    public boolean addIngredients ( final List<Ingredient> ingrs ) {
        for ( final Ingredient newIngr : ingrs ) {
            for ( final Ingredient invIngr : ingredients ) {
                if ( newIngr.getName().equals( invIngr.getName() ) ) {

                    this.checkAmount( newIngr.getAmount().toString() );

                    invIngr.setAmount( invIngr.getAmount() + newIngr.getAmount() );
                }
            }
        }
        return true;
    }

    /**
     * Adds a new ingredient into the inventory
     *
     * @param i
     *            new ingredient to be added
     *
     * @throws IllegalArgumentException
     *             if the ingredient being added already exists in the inventory
     */
    public void addIngredientToInventory ( final Ingredient i ) {
        for ( final Ingredient ing : ingredients ) {
            if ( ing.getName().equals( i.getName() ) ) {
                throw new IllegalArgumentException();
            }
        }
        ingredients.add( i );
    }

    /**
     * Updates the amount for an ingredient in the inventory
     *
     * @param name
     *            name of Ingredient to be updated
     * @param amount
     *            new amount to set for Ingredient
     *
     * @throws IllegalArgumentException
     *             if given amount is negative or given name doesn't match any
     *             existing ingredients in the inventory
     */
    public void updateIngredient ( final String name, final Integer amount ) {
        if ( amount < 0 ) {
            throw new IllegalArgumentException();
        }
        boolean validIng = false;
        for ( final Ingredient i : ingredients ) {
            if ( i.getName().equals( name ) ) {
                i.setAmount( amount );
                validIng = true;
            }
        }
        if ( !validIng ) {
            throw new IllegalArgumentException();
        }
    }

    /**
     * Returns a string describing the current contents of the inventory.
     *
     * @return String
     */
    @Override
    public String toString () {
        final StringBuffer buf = new StringBuffer();

        for ( final Ingredient i : ingredients ) {
            buf.append( i.toString() );
            buf.append( '\n' );
        }

        return buf.toString();
    }

}
