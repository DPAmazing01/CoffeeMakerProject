package edu.ncsu.csc.CoffeeMaker.models;

public enum Role {
    CUSTOMER(Roles.CUSTOMER), MANAGER(Roles.MANAGER), EMPLOYEE(Roles.EMPLOYEE), GUEST(Roles.GUEST);

    private final String role;

    private Role(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return role;
    }

    /**
     * Constant expressions of roles to strings
     */
    public static class Roles {
        // design from https://stackoverflow.com/a/16384334
        public static final String CUSTOMER = "CUSTOMER";
        public static final String MANAGER = "MANAGER";
        public static final String EMPLOYEE = "EMPLOYEE";
        public static final String GUEST = "GUEST";
    }
}
