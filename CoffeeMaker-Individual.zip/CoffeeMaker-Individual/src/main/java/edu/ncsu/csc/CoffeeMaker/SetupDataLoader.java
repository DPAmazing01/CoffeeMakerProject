package edu.ncsu.csc.CoffeeMaker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import edu.ncsu.csc.CoffeeMaker.models.Role;
import edu.ncsu.csc.CoffeeMaker.services.UserService;

@Component
public class SetupDataLoader implements ApplicationListener<ContextRefreshedEvent> {
    public static final String MANAGER_USERNAME = "testmanager";
    public static final Role   MANAGER_ROLE     = Role.MANAGER;

    boolean                    alreadySetup     = false;

    @Autowired
    private UserService userSerivce;

    @Override
    @Transactional
    public void onApplicationEvent ( final ContextRefreshedEvent event ) {

        if ( alreadySetup ) {
            return;
        }

        userSerivce.registerUser(MANAGER_USERNAME, "testpassword", Role.MANAGER);

        userSerivce.registerUser("employee", "testpassword", Role.EMPLOYEE);

        alreadySetup = true;
    }

}
