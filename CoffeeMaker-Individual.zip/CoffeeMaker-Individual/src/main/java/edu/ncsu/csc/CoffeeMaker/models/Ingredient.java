package edu.ncsu.csc.CoffeeMaker.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Ingredient extends DomainObject {

    @Id
    @GeneratedValue
    private Long    id;
    private Integer amount;
    private String  name;

    public Ingredient ( final String ingredient, final Integer amount ) {
        super();
        setAmount( amount );
        setName( ingredient );
    }

    public Ingredient () {
        super();
    }

    public Integer getAmount () {
        return amount;
    }

    public void setAmount ( final Integer amount ) {
        if ( amount >= 0 ) {
            this.amount = amount;
        }
        else {
            throw new IllegalArgumentException();
        }
    }

    @Override
    public Long getId () {
        return id;
    }

    public void setId ( final Long id ) {
        this.id = id;
    }

    public String getName () {
        return name;
    }

    public void setName ( final String name ) {
        if ( name != null ) {
            this.name = name;
        }
        else {
            throw new IllegalArgumentException();
        }
    }

    @Override
    public String toString () {
        return "[Ingredient: " + id + ", [ingredient=" + name + ", amount=" + amount + "]";
    }

}
