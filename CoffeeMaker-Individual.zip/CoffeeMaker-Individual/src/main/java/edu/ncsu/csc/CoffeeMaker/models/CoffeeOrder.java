package edu.ncsu.csc.CoffeeMaker.models;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 * Orders for the Coffeemaker. An order has a recipe to be fulfilled, a user
 * that placed
 */
@Entity
public class CoffeeOrder extends DomainObject {

    /** Display id **/
    @Id
    private String  date;

    /** The Recipe of the order */
    @ManyToOne ( cascade = CascadeType.ALL, fetch = FetchType.EAGER )
    private Recipe  recipe;

    /** The user who placed the order */
    @ManyToOne ( cascade = CascadeType.ALL, fetch = FetchType.EAGER )
    private User    user;

    /** Whether the order has been fulfilled or not */
    private boolean fulfilled;

    /** Whether the order has been picked up or not */
    private boolean pickedUp;

    /**
     * Creates a default order for the coffee maker.
     */
    public CoffeeOrder () {
        // Get the current date and time
        final LocalDateTime currentDateTime = LocalDateTime.now();

        // Define the format for the output string
        final DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "yyyy-MM-dd HH:mm:ss" );

        // Format the LocalDateTime object into a string
        final String formattedDateTime = currentDateTime.format( formatter );

        this.date = formattedDateTime;
        this.fulfilled = false;
        this.pickedUp = false;
    }

    /**
     * Returns the display id
     *
     * @return
     */
    public String getDate () {
        return date;
    }

    public void setDate ( final String date ) {
        this.date = date;
    }

    /**
     * Returns the recipe of the order
     *
     * @return the recipe of the order
     */
    public Recipe getRecipe () {
        return recipe;
    }

    /**
     * Sets the recipe of the order
     *
     * @param recipe
     *            the recipe to be set
     */
    public void setRecipe ( final Recipe recipe ) {
        this.recipe = recipe;
    }

    /**
     * Returns the user who placed the recipe
     *
     * @return the user who placed the recipe
     */
    public User getUser () {
        return user;
    }

    /**
     * Sets the user who placed the recipe
     *
     * @param user
     *            the user to be set
     */
    public void setUser ( final User user ) {
        this.user = user;
    }

    /**
     * Returns true if the order has been fulfilled
     *
     * @return whether the order has been fulfilled or not
     */
    public boolean isFulfilled () {
        return fulfilled;
    }

    /**
     * Sets fulfilled to true if fulfilled
     *
     * @param fulfilled
     *            whether the order is fulfilled
     */
    public void setFulfilled ( final boolean fulfilled ) {
        this.fulfilled = fulfilled;
    }

    /**
     * Returns true if the order has been picked up
     *
     * @return whether the order has been picked up or not
     */
    public boolean isPickedUp () {
        return pickedUp;
    }

    /**
     * Sets fulfilled to true if fulfilled
     *
     * @param fulfilled
     *            whether the order is fulfilled
     */
    public void setPickedUp ( final boolean pickedUp ) {
        this.pickedUp = pickedUp;
    }

    /**
     * Returns a string representation of an order to be displayed.
     *
     * @return String [Order# ] : User
     */
    @Override
    public String toString () {
        return "[Order : " + this.date + "] : " + this.user.getName();
    }

    /**
     * Checks whether an order object equals this object
     */
    @Override
    public boolean equals ( final Object obj ) {
        if ( this == obj ) {
            return true;
        }
        if ( obj == null ) {
            return false;
        }
        if ( getClass() != obj.getClass() ) {
            return false;
        }
        final CoffeeOrder other = (CoffeeOrder) obj;
        return Objects.equals( date, other.date ) && Objects.equals( user, other.user )
                && Objects.equals( recipe, other.recipe );
    }

    /**
     * Returns the display id of the order
     *
     * @return the display id of the order
     */
    @Override
    public String getId () {
        return date;
    }

}
