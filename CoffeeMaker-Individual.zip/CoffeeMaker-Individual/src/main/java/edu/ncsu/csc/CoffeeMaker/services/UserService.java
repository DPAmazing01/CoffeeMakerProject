package edu.ncsu.csc.CoffeeMaker.services;

import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.lang.Nullable;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import edu.ncsu.csc.CoffeeMaker.models.Role;
import edu.ncsu.csc.CoffeeMaker.models.User;
import edu.ncsu.csc.CoffeeMaker.repositories.UserRepository;
import edu.ncsu.csc.CoffeeMaker.WebSecurityConfig;

/**
 * The RecipeService is used to handle CRUD operations on the Recipe model. In
 * addition to all functionality from `Service`, we also have functionality for
 * retrieving a single Recipe by name.
 *
 * @author Kai Presler-Marshall
 *
 */
@Component
@Transactional
public class UserService extends Service<User, String> implements UserDetailsService {

    /**
     * RecipeRepository, to be autowired in by Spring and provide CRUD
     * operations on Recipe model.
     */
    @Autowired
    private UserRepository userRepository;

    @Override
    protected JpaRepository<User, String> getRepository () {
        return userRepository;
    }

    /**
     * Override a recipe with the provided name
     *
     * @param name
     *            Name of the recipe to find
     * @return found recipe, null if none
     */
    public User findByName ( final String name ) {
        return userRepository.findByName( name );
    }

    /**
     * Makes spring UserDetails from a user
     * @return the user details
     */
    public static UserDetails makeUserDetails(User user) {
        return org.springframework.security.core.userdetails.User
            .builder()
                .username( user.getName() )
                .password( user.getPassword() )
                .roles( user.getRole().toString() )
                .build();
    }

    @Override
    public UserDetails loadUserByUsername ( final String username ) throws UsernameNotFoundException {
        final User user = findByName( username );

        if ( user == null ) {
            throw new UsernameNotFoundException( "No user exists with name " + username );
        }

        return makeUserDetails(user);
    }

    /** Random used for guest username creation */
    private final Random random = new Random();

    /**
     * Tries to generate a random unique guest name
     * Can fail if all guest names are already taken
     * @return the guest name, or null if it failed
     */
    @Nullable
    String generateUniqueGuestName() {
        String guest_prefix = "guest_";

        // how many times to try to get a unique guest name
        int max_attempts = 10;

        for (int i = 0; i < max_attempts; i++) {
            String name = guest_prefix + random.nextInt();
            if (findByName(name) == null) {
                return name;
            }
        }

        return null;
    }

    /**
     * Tries to create a new user with given attributes
     * @param password may be null
     * @return the newly created user, or null if the user already exists
     */
    public User registerUser(String username, @Nullable String password, Role role) {
        if (findByName(username) != null) {
            return null;
        }

        //todo check for duplicates
        User user = new User();
        user.setName(username);
        user.setRole(role);
        if (password != null) {
            user.setPassword(WebSecurityConfig.passwordEncoder.encode(password));
        }
        save(user);

        return user;
    }

    /**
     * Tries to create a new guest user.
     * @return the newly created user, or null if the creation failed
     */
    @Nullable
    public User registerGuest() {
        String name = generateUniqueGuestName();
        if (name == null) {
            return null;
        }

        return registerUser(name, null, Role.GUEST);
    }
}
