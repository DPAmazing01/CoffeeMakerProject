package edu.ncsu.csc.CoffeeMaker.models;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Users for the coffee maker. A user has a distinct username, password, and an
 * associated Role that determines its permissions.
 *
 * @author Brian Yngve
 */
@Entity
public class User extends DomainObject {

    /** Username */
    @Id
    private String name;

    /** Password */
    private String password;

    /** User Role */
    private Role   role;

    /**
     * Creates a default User for the coffee maker.
     */
    public User () {
        this.name = "";
        this.password = "";
        this.role = Role.CUSTOMER;
    }

    /**
     * Returns user's username.
     *
     * @return Returns the name.
     */
    public String getName () {
        return name;
    }

    /**
     * Sets the user name.
     *
     * @param name
     *            The name to set.
     */
    public void setName ( final String name ) {
        this.name = name;
    }

    /**
     * Returns the (encrypted) password of the user.
     *
     * @return Returns the password.
     */
    public String getPassword () {
        return password;
    }

    /**
     * Sets the user password.
     *
     * @param price
     *            The price to set.
     */
    public void setPassword ( final String pswd ) {
        this.password = pswd;
    }

    /**
     * Returns the user's role
     *
     * @return Returns the password.
     */
    public Role getRole () {
        return this.role;
    }

    /**
     * Sets the user's role.
     *
     * @param price
     *            The price to set.
     */
    public void setRole ( final Role role ) {
        this.role = role;
    }

    /**
     * Returns the name of the user.
     *
     * @return String [Role] Username
     */
    @Override
    public String toString () {
        return "[" + this.role + "] " + this.name;
    }

    /**
     *
     */
    @Override
    public boolean equals ( final Object obj ) {
        if ( this == obj ) {
            return true;
        }
        if ( obj == null ) {
            return false;
        }
        if ( getClass() != obj.getClass() ) {
            return false;
        }
        final User other = (User) obj;
        return Objects.equals( name, other.name ) && Objects.equals( password, other.password ) && role == other.role;
    }

    /**
     * Get the ID of the User
     *
     * @return the ID
     */
    @Override
    public String getId () {
        return name;
    }

}
