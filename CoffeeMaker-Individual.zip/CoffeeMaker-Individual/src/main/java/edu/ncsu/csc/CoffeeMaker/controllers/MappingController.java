package edu.ncsu.csc.CoffeeMaker.controllers;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

/**
 * Controller class for the URL mappings for CoffeeMaker. The controller returns
 * the approprate HTML page in the /src/main/resources/templates folder. For a
 * larger application, this should be split across multiple controllers.
 *
 * @author Kai Presler-Marshall
 */
@Controller
public class MappingController {
    public static final String LOGIN_PAGE       = "/login";
    public static final String INDEX_PAGE       = "/index.html";
    public static final String INDEX_PAGE2      = "/";
    public static final String ROLE_SELECT_PAGE = "/roleselect.html";

    /**
     * On a GET request to /index, the IndexController will return
     * /src/main/resources/templates/index.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( INDEX_PAGE )
    public View index ( final Model model ) {
        return new RedirectView( ROLE_SELECT_PAGE );
    }

    /**
     * On a GET request to /index, the IndexController will return
     * /src/main/resources/templates/index.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( INDEX_PAGE2 )
    public View index2 ( final Model model ) {
        return new RedirectView( ROLE_SELECT_PAGE );
    }

    /**
     * On a GET request to /index, the IndexController will return
     * /src/main/resources/templates/index.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( LOGIN_PAGE )
    public void loginPage ( final Model model ) {
        model.addAttribute( "guest_login_endpoint", APILoginController.GUEST_LOGIN_ENDPOINT );
    }

    /**
     * On a GET request to /recipe, the RecipeController will return
     * /src/main/resources/templates/recipe.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @PreAuthorize ( "hasAuthority('MANAGER', 'EMPLOYEE')" )
    @GetMapping ( { "/recipe", "/recipe.html" } )
    public String addRecipePage ( final Model model ) {
        return "recipe";
    }

    /**
     * On a GET request to /deleterecipe, the DeleteRecipeController will return
     * /src/main/resources/templates/deleterecipe.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @PreAuthorize ( "hasAuthority('MANAGER', 'EMPLOYEE')" )
    @GetMapping ( { "/deleterecipe", "/deleterecipe.html" } )
    public String deleteRecipeForm ( final Model model ) {
        return "deleterecipe";
    }

    /**
     * On a GET request to /editrecipe, the EditRecipeController will return
     * /src/main/resources/templates/editrecipe.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @PreAuthorize ( "hasAuthority('MANAGER', 'EMPLOYEE')" )
    @GetMapping ( { "/editrecipe", "/editrecipe.html" } )
    public String editRecipeForm ( final Model model ) {
        return "editrecipe";
    }

    /**
     * On a GET request to /editrecipe, the EditRecipeController will return
     * /src/main/resources/templates/editrecipe.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @PreAuthorize ( "hasAuthority('MANAGER', 'EMPLOYEE')" )
    @GetMapping ( { "/editrecipeselect", "/editrecipeselect.html" } )
    public String editRecipeSelectForm ( final Model model ) {
        return "editrecipeselect";
    }

    /**
     * Handles a GET request for inventory. The GET request provides a view to
     * the client that includes the list of the current ingredients in the
     * inventory and a form where the client can enter more ingredients to add
     * to the inventory.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @PreAuthorize ( "hasAuthority('MANAGER')" )
    @GetMapping ( { "/inventory", "/inventory.html" } )
    public String inventoryForm ( final Model model ) {
        return "inventory";
    }

    /**
     * On a GET request to /makecoffee, the MakeCoffeeController will return
     * /src/main/resources/templates/makecoffee.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @PreAuthorize ( "hasAuthority('CUSTOMER')" )
    @GetMapping ( { "/makecoffee", "/makecoffee.html" } )
    public String makeCoffeeForm ( final Model model ) {
        return "makecoffee";
    }

    /**
     * On a GET request to /addingredient, the MakeCoffeeController will return
     * /src/main/resources/templates/addingredient.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @PreAuthorize ( "hasAuthority('MANAGER')" )
    @GetMapping ( { "/addingredient", "/addingredient.html" } )
    public String addIngredientForm ( final Model model ) {
        return "addingredient";
    }

    /**
     * On a GET request to /addrecipe, the MakeCoffeeController will return
     * /src/main/resources/templates/addRecipe.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @PreAuthorize ( "hasAuthority('MANAGER', 'EMPLOYEE')" )
    @GetMapping ( { "/addRecipe", "/addRecipe.html" } )
    public String addRecipeForm ( final Model model ) {
        return "addRecipe";
    }

    @GetMapping ( { "/hello", "/hello.html" } )
    public String hello ( final Model model ) {
        return "hello";
    }

    @GetMapping ( { "/signup", "/signUpPage.html" } )
    public String signUp ( final Model model ) {
        model.addAttribute( "register_customer_endpoint", APIUserController.REGISTER_CUSTOMER_ENDPOINT );
        return "signUpPage";
    }

    @GetMapping ( { "/customer", "/customer.html" } )
    public String customerIndex ( final Model model ) {
        return "customerHomePage";
    }

    @GetMapping ( { "/signupEmployee", "/signupEmployee.html" } )
    public String signUpEmployee ( final Model model ) {
        model.addAttribute( "register_employee_endpoint", APIUserController.REGISTER_EMPLOYEE_ENDPOINT );
        return "signUpPageEmployee";
    }

    @GetMapping ( { "/managerPage", "/managerPage.html" } )
    public String managerPage ( final Model model ) {
        return "managerHomePage";
    }

    @GetMapping ( { "/employeePage", "/employeePage.html" } )
    public String employeePage ( final Model model ) {
        return "employeeHomePage";
    }

    @GetMapping ( { "/guestPage", "/guestPage.html" } )
    public String guestPage ( final Model model ) {
        return "guestHomePage";
    }

    @GetMapping ( ROLE_SELECT_PAGE )
    public void roleSelect ( final Model model ) {
        // todo
        // model.addAttribute("role", todo);
    }

    @GetMapping ( { "/viewAndFulfill", "/viewAndFulfill.html" } )
    public String viewAndFulfill ( final Model model ) {
        return "viewFulfillOrders";
    }

    @GetMapping ( { "/customerPickup", "/customerPickup.html" } )
    public String customerPickup ( final Model model ) {
        return "customerPickupOrder";
    }
}
