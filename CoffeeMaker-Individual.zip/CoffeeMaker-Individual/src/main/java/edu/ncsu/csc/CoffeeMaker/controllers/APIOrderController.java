package edu.ncsu.csc.CoffeeMaker.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import edu.ncsu.csc.CoffeeMaker.models.CoffeeOrder;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.models.User;
import edu.ncsu.csc.CoffeeMaker.services.CoffeeOrderService;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;
import edu.ncsu.csc.CoffeeMaker.services.UserService;

/**
 * This is the controller that holds the REST endpoints that handle CRUD
 * operations for Orders.
 *
 * Spring will automatically convert all of the ResponseEntity and List results
 * to JSON
 *
 * @author Kai Presler-Marshall
 * @author Michelle Lemons
 *
 */
@SuppressWarnings ( { "unchecked", "rawtypes" } )
@RestController
public class APIOrderController extends APIController {

    /**
     * OrderService object, to be autowired in by Spring to allow for
     * manipulating the Order model
     */
    @Autowired
    private CoffeeOrderService service;

    @Autowired
    private RecipeService      recipeService;

    @Autowired
    private UserService        userService;

    /**
     * REST API method to provide GET access to all orders in the system for an
     * employee
     *
     * @return JSON representation of all order
     */
    @GetMapping ( EMPLOYEE_PATH + "order" )
    public List<CoffeeOrder> getOrder () {
        return service.findAll();
    }

    /**
     * REST API method to provide GET access to all orders in the system for a
     * customer
     *
     * @return JSON representation of all order
     */
    @GetMapping ( CUSTOMER_PATH + "order" )
    public List<CoffeeOrder> getOrderCustomer () {
        return service.findAll();
    }

    /**
     * REST API method to provide POST access to the Order model. This is used
     * to create a new Order by automatically converting the JSON RequestBody
     * provided to a Order object. Invalid JSON will fail.
     *
     * @param order
     *            The valid Order to be saved.
     * @return ResponseEntity indicating success if the Orders could be saved to
     *         the inventory, or an error if it could not be
     */
    @PostMapping ( CUSTOMER_PATH + "order/{recipeName}" )
    public ResponseEntity placeOrder ( @PathVariable final String recipeName, @RequestBody final String userName ) {
        final CoffeeOrder order = new CoffeeOrder();
        final Recipe recipe = recipeService.findByName( recipeName );
        final User user = userService.findById( userName );
        order.setUser( user );
        order.setRecipe( recipe );
        if ( null != service.findByDate( order.getDate() ) ) {
            return new ResponseEntity( errorResponse( "Order with the ID " + order.getDate() + " already exists" ),
                    HttpStatus.CONFLICT );
        }
        service.save( order );
        return new ResponseEntity( successResponse( order.getDate() + " successfully created" ), HttpStatus.OK );

    }

    /**
     * REST API method to provide PUT access to the Order model. This is used to
     * update the fulfilled status of all orders by automatically converting the
     * JSON RequestBody provided to a Order object. Invalid JSON will fail.
     *
     * @param recipe
     *            The valid Recipe to be saved.
     * @return ResponseEntity indicating success if the Recipe could be saved to
     *         the inventory, or an error if it could not be
     */
    @PutMapping ( EMPLOYEE_PATH + "order/fulfilled" )
    public ResponseEntity fulfillOrder ( @RequestBody final CoffeeOrder order ) {
        try {
            // Find the order in the database by ID
            final CoffeeOrder existingOrder = service.findByDate( order.getDate() );

            // Update the 'fulfilled' status to true
            if ( existingOrder != null ) {
                existingOrder.setFulfilled( true );
                service.save( existingOrder );
            }

            return new ResponseEntity<>( HttpStatus.OK );
        }
        catch (

        final Exception e ) {
            return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR );
        }

    }

    /**
     * REST API method to provide PUT access to the Order model. This is used to
     * update the fulfilled status of all orders by automatically converting the
     * JSON RequestBody provided to a Order object. Invalid JSON will fail.
     *
     * @param recipe
     *            The valid Recipe to be saved.
     * @return ResponseEntity indicating success if the Recipe could be saved to
     *         the inventory, or an error if it could not be
     */
    @PutMapping ( CUSTOMER_PATH + "order/pickedUp" )
    public ResponseEntity pickUpOrder ( @RequestBody final CoffeeOrder order ) {
        try {
            // Find the order in the database by ID
            final CoffeeOrder existingOrder = service.findByDate( order.getDate() );

            // Update the 'fulfilled' status to true
            if ( existingOrder != null ) {
                existingOrder.setPickedUp( true );
                service.save( existingOrder );
            }
            return new ResponseEntity<>( HttpStatus.OK );
        }
        catch ( final Exception e ) {
            return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR );
        }

    }

}
