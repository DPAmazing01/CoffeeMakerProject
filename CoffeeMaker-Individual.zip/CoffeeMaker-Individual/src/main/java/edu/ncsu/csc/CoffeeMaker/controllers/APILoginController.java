package edu.ncsu.csc.CoffeeMaker.controllers;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import edu.ncsu.csc.CoffeeMaker.models.User;
import edu.ncsu.csc.CoffeeMaker.services.UserService;

@RestController
public class APILoginController extends APIController {
    public static final String LOGIN_SUCCESS_URL = MappingController.ROLE_SELECT_PAGE;
    public static final String LOGIN_FAIL_URL = MappingController.LOGIN_PAGE + "?error";
    public static final String GUEST_LOGIN_ENDPOINT = APIController.BASE_PATH + "login_as_guest";

    @Autowired
    private UserService userService;

    @PostMapping(GUEST_LOGIN_ENDPOINT)
    public View login (HttpServletRequest request) {
        //todo test more
        //todo currently insecure
        //todo dont trash old session instead just use new one
        try {
            request.logout();
        } catch (ServletException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
        }

        HttpSession session = request.getSession();
        if (session == null) {
            // todo improve logging
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
        }

        // make a new guest user
        User guest = userService.registerGuest();
        if (guest == null) {
            // todo improve logging
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
        // log the user in
        // we do this by messing around with spring
        // idk what the correct way to do this is lol
        
        UserDetails springUser = UserService.makeUserDetails(guest);
        UsernamePasswordAuthenticationToken guestAuthentication = new UsernamePasswordAuthenticationToken(springUser, null, springUser.getAuthorities());

        SecurityContext context = new SecurityContextImpl(guestAuthentication);
        session.setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, context);
        //todo
        SecurityContextHolder.setContext(context);

        return new RedirectView(LOGIN_SUCCESS_URL);
    }
}
