package edu.ncsu.csc.CoffeeMaker.services;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import edu.ncsu.csc.CoffeeMaker.models.CoffeeOrder;
import edu.ncsu.csc.CoffeeMaker.repositories.CoffeeOrderRepository;

/**
 * The RecipeService is used to handle CRUD operations on the Recipe model. In
 * addition to all functionality from `Service`, we also have functionality for
 * retrieving a single Recipe by name.
 *
 * @author Kai Presler-Marshall
 *
 */
@Component
@Transactional
public class CoffeeOrderService extends Service<CoffeeOrder, Integer> {

    /**
     * RecipeRepository, to be autowired in by Spring and provide CRUD
     * operations on Recipe model.
     */
    @Autowired
    private CoffeeOrderRepository orderRepository;

    @Override
    protected JpaRepository<CoffeeOrder, Integer> getRepository () {
        return orderRepository;
    }

    /**
     * Find a order with the provided id
     *
     * @param id
     *            Name of the order to find
     * @return found recipe, null if none
     */
    public CoffeeOrder findByDate ( final String date ) {

        return orderRepository.findByDate( date );

    }
}
