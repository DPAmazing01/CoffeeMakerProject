package edu.ncsu.csc.CoffeeMaker.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.ncsu.csc.CoffeeMaker.models.CoffeeOrder;

/**
 * OrderRepository is used to provide CRUD operations for the Order model.
 * Spring will generate appropriate code with JPA.
 *
 * @author Kai Presler-Marshall
 *
 */
public interface CoffeeOrderRepository extends JpaRepository<CoffeeOrder, Integer> {

    /**
     * Finds a Order object with the provided ID. Spring will generate code to
     * make this happen.
     *
     * @param id
     *            id of the order
     * @return Found order, null if none.
     */
    CoffeeOrder findByDate ( String date );

}
