package edu.ncsu.csc.CoffeeMaker.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import edu.ncsu.csc.CoffeeMaker.models.Role;
import edu.ncsu.csc.CoffeeMaker.models.User;
import edu.ncsu.csc.CoffeeMaker.services.UserService;

@SuppressWarnings ( { "unchecked", "rawtypes" } )
@RestController
public class APIUserController extends APIController {
    public static final String REGISTER_CUSTOMER_ENDPOINT = BASE_PATH + "register";
    public static final String REGISTER_EMPLOYEE_ENDPOINT = MANAGER_PATH + "register";

    @Autowired
    private UserService        userService;

    /**
     * REST API method to provide GET access to a specific user, as indicated by
     * the path variable provided (the name of the user desired)
     *
     * @param name
     *            user name
     * @return response to the request
     */
    @GetMapping ( EMPLOYEE_PATH + "users/{name}" )
    public ResponseEntity getUser ( @PathVariable final String name ) {

        final User user = userService.findByName( name );

        if ( null == user ) {
            return new ResponseEntity( HttpStatus.NOT_FOUND );
        }

        return new ResponseEntity( user, HttpStatus.OK );
    }

    /**
     * REST API method to provide POST access to the User model. This is used to
     * create a new User by automatically converting the JSON RequestBody
     * provided to a User object. Invalid JSON will fail.
     *
     * @param user
     *            The valid User to be saved.
     * @return ResponseEntity indicating success if the User could be saved to
     *         the inventory, or an error if it could not be
     */
    @PostMapping ( REGISTER_CUSTOMER_ENDPOINT )
    public ResponseEntity registerCustomer ( @RequestBody final User user ) {
        return registerUser( user, Role.CUSTOMER );
    }

    /**
     * REST API method to provide POST access to the User model. This is used to
     * create a new User by automatically converting the JSON RequestBody
     * provided to a User object. Invalid JSON will fail.
     *
     * @param user
     *            The valid User to be saved.
     * @return ResponseEntity indicating success if the User could be saved to
     *         the inventory, or an error if it could not be
     */
    @PostMapping ( REGISTER_EMPLOYEE_ENDPOINT )
    public ResponseEntity registerEmployee ( @RequestBody final User user ) {
        return registerUser( user, Role.EMPLOYEE );
    }

    /**
     * REST API method to provide POST access to the User model. This is used to
     * create a new User by automatically converting the JSON RequestBody
     * provided to a User object. Invalid JSON will fail.
     *
     * @param user
     *            The valid User to be saved.
     * @return ResponseEntity indicating success if the User could be saved to
     *         the inventory, or an error if it could not be
     */
    private ResponseEntity registerUser ( final User user, final Role role ) {
        if ( userService.registerUser( user.getName(), user.getPassword(), role ) == null ) {
            return new ResponseEntity( HttpStatus.CONFLICT );
        }

        return new ResponseEntity( HttpStatus.CREATED );
    }

    /**
     * REST API method to provide GET access to all recipes in the system
     *
     * @return JSON representation of all users
     */
    @GetMapping ( EMPLOYEE_PATH + "users" )
    public List<User> getUsers () {
        return userService.findAll();
    }

    /**
     * REST API method to allow deleting a User from the CoffeeMaker's
     * Inventory, by making a DELETE request to the API endpoint and indicating
     * the recipe to delete (as a path variable)
     *
     * @param name
     *            The name of the User to delete
     * @return Success if the recipe could be deleted; an error if the recipe
     *         does not exist
     */
    @DeleteMapping ( EMPLOYEE_PATH + "users/{name}" )
    public ResponseEntity deleteUser ( @PathVariable final String name ) {
        final User recipe = userService.findByName( name );
        if ( null == recipe ) {
            return new ResponseEntity( errorResponse( "No user found for name " + name ), HttpStatus.NOT_FOUND );
        }
        userService.delete( recipe );

        return new ResponseEntity( successResponse( name + " was deleted successfully" ), HttpStatus.OK );
    }

    /**
     * REST API endpoint to provide update access to a User in CoffeeMaker. This
     * will update the User in the CoffeeMaker by altering the name or amount
     *
     * @param user
     *            the User to overwrite the existing one with.
     * @return response to the request
     */
    // @PutMapping ( BASE_PATH + "users" )
    // public ResponseEntity updateUser ( @RequestBody final User user ) {
    // final User userCurrent = userService.findByName( user.getName() );
    //
    // if ( userCurrent == null ) {
    // return new ResponseEntity( errorResponse( "No matching user found." ),
    // HttpStatus.NOT_FOUND );
    // }
    //
    // userCurrent.setName( user.getName() );
    // userCurrent.setPassword( user.getPassword() );
    // userCurrent.setRole( user.getRole() );
    //
    // userService.save( userCurrent );
    // return new ResponseEntity( userCurrent, HttpStatus.OK );
    // }

    /**
     * Gets the current logged in role.
     *
     * Adapted from iTrust2 getRole method by Kai Presler-Marshall, Lauren
     * Murillo and Alex Bowen
     *
     * @return role of the currently logged in user.
     */
    @GetMapping ( PROTECTED_PATH + "role" )
    // @PreAuthorize("#role == authentication.principal.role")
    // @ResponseBody
    public String getRole () throws Exception {
        final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if ( authentication == null ) {
            throw new Exception( "authentication was null " );
        }

        // make sure there is only 1 role set
        if ( authentication.getAuthorities().size() != 1 ) {
            throw new ResponseStatusException( HttpStatus.FORBIDDEN, "improper authorities" );
            // throw new Exception("authorities was not size 1, instead got size
            // " + authentication.getAuthorities().size() + ", does user have
            // multiple roles?");
        }

        // get the first element and return it
        final String role = authentication.getAuthorities().iterator().next().getAuthority();

        // todo check that this is a valid Role enum? may not be necessary
        // however

        // strip the ROLE_: ROLE_CUSTOMER -> CUSTOMER
        return role.substring( 5 );
    }

    /*
     * This method is weird. AngularJS won't accept the user name in any form
     * except JSON, so we have to do this weird JSON-workaround.
     */
    @GetMapping ( CUSTOMER_PATH + "name" )
    public ResponseEntity<String> getUsername () {
        final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        final String currentPrincipalName = authentication.getName();
        return new ResponseEntity<String>( successResponse( currentPrincipalName ), HttpStatus.OK );
        // "{\"username\": \"" + currentPrincipalName + "\"}";
    }

    /**
     * Checks if the current user has a `role`.
     *
     * @param role
     *            role to check for the user to have.
     * @return true if the user has `role`, false otherwise.
     * 
     *         protected boolean hasRole ( final String role ) { // get security
     *         context from thread local final Authentication authentication =
     *         SecurityContextHolder.getContext().getAuthentication(); if (
     *         authentication == null ) { return false; }
     * 
     *         for ( final GrantedAuthority auth :
     *         authentication.getAuthorities() ) { if ( role.equals(
     *         auth.getAuthority() ) ) { return true; } } return false; }
     */

}
