package edu.ncsu.csc.CoffeeMaker;

import java.util.EnumSet;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;

import edu.ncsu.csc.CoffeeMaker.controllers.APIController;
import edu.ncsu.csc.CoffeeMaker.controllers.APILoginController;
import edu.ncsu.csc.CoffeeMaker.controllers.MappingController;
import edu.ncsu.csc.CoffeeMaker.models.Role;
import edu.ncsu.csc.CoffeeMaker.services.UserService;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    public static final String LOGOUT_SUCCESS_URL = MappingController.ROLE_SELECT_PAGE;
    public static final String LOGOUT_PAGE = "/logout";

    // todo idk how spring recommends this be stored
    // maybe use @Bean?? idk what a bean is
    public static final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Autowired
    private UserService                 userService;

    /*
     * @Bean
     * @Override public SecurityFilterChain securityFilterChain ( HttpSecurity
     * http ) throws Exception { //
     * https://docs.spring.io/spring-security/site/docs/3.2.3.RELEASE/reference/
     * htmlsingle/#jc-httpsecurity //
     * https://docs.spring.io/spring-security/site/docs/current/api/org/
     * springframework/security/config/annotation/web/builders/HttpSecurity.html
     * return http.authorizeRequests().and().formLogin( ( form ) ->
     * form.loginPage( "/login" ).permitAll() ) .logout( ( logout ) ->
     * logout.permitAll() ).build(); }
     */

    // https://docs.spring.io/spring-security/site/docs/current/api/org/springframework/security/core/userdetails/UserDetailsService.html

    /*
     * @Bean
     * @Override public UserDetailsService userDetailsService () { return new
     * UserDetailsService(); }
     */

    @Override
    protected void configure ( final HttpSecurity http ) throws Exception {
        final String[] roles = EnumSet.allOf( Role.class ).stream().map( ( role ) -> role.toString() )
                .collect( Collectors.toList() ).toArray( new String[0] );

        // todo denyAll?
        // todo formLogin can be configured

        // have to restrict pages one by one since signup() must be accessible
        // to all
        //https://javadoc.io/static/org.springframework.security/spring-security-config/5.3.6.RELEASE/org/springframework/security/config/annotation/web/configurers/FormLoginConfigurer.html
        http.authorizeRequests()
                .mvcMatchers( HttpMethod.GET, "/addRecipe" ).hasAnyRole( Role.Roles.MANAGER, Role.Roles.EMPLOYEE )
                .mvcMatchers( HttpMethod.GET, "/recipe" ).hasAnyRole( Role.Roles.MANAGER, Role.Roles.EMPLOYEE )
                .mvcMatchers( HttpMethod.GET, "/addingredient" ).hasAnyRole( Role.Roles.MANAGER, Role.Roles.EMPLOYEE )
                .mvcMatchers( HttpMethod.GET, "/editrecipe" ).hasAnyRole( Role.Roles.MANAGER, Role.Roles.EMPLOYEE )
                .mvcMatchers( HttpMethod.GET, "/deleterecipe" ).hasAnyRole( Role.Roles.MANAGER, Role.Roles.EMPLOYEE )
                .mvcMatchers( HttpMethod.GET, "/addRecipe" ).hasAnyRole( Role.Roles.MANAGER, Role.Roles.EMPLOYEE )
                .mvcMatchers( HttpMethod.GET, "/inventory" ).hasRole( Role.Roles.MANAGER )
                .mvcMatchers( HttpMethod.GET, "/makecoffee" ).hasAnyRole( Role.Roles.CUSTOMER, Role.Roles.GUEST )
                // pages
                //.mvcMatchers( HttpMethod.GET, MappingController.LOGIN_PAGE ).permitAll()
                .mvcMatchers( HttpMethod.GET, MappingController.ROLE_SELECT_PAGE ).hasAnyRole(roles)
                //.mvcMatchers( HttpMethod.GET, MappingController.INDEX_PAGE ).permitAll()
                //.mvcMatchers( HttpMethod.GET, MappingController.INDEX_PAGE2 ).permitAll()
                // special spring generated pages
                //.antMatchers( LOGOUT_PAGE ).hasAnyRole(roles)
                // standard API endpoints
                .antMatchers( APIController.BASE_PATH + "register" ).permitAll()
                .antMatchers( APIController.PROTECTED_PATH + "**" ).hasAnyRole( roles )
                .antMatchers( APIController.CUSTOMER_PATH + "**" ).hasAnyRole( Role.Roles.CUSTOMER, Role.Roles.GUEST )
                .antMatchers( APIController.EMPLOYEE_PATH + "**" ).hasAnyRole( Role.Roles.EMPLOYEE, Role.Roles.MANAGER )
                .antMatchers( APIController.MANAGER_PATH + "**" ).hasRole( Role.Roles.MANAGER )
                // special API endpoints
                .antMatchers( APILoginController.GUEST_LOGIN_ENDPOINT ).permitAll()
                // default allow
                .anyRequest().permitAll()
                .and()
            // logout endpoint? page? idk todo
            .logout()
                .logoutUrl(LOGOUT_PAGE)
                .logoutSuccessUrl(LOGOUT_SUCCESS_URL)
                .and()
            // login form
            .formLogin()
                // this should be the login page on a GET request
                // but spring should handle login POST requests
                .loginPage(MappingController.LOGIN_PAGE)
                .defaultSuccessUrl(APILoginController.LOGIN_SUCCESS_URL)
                .failureUrl(APILoginController.LOGIN_FAIL_URL)
                .and()
            // csrf
            .csrf()
                .disable();
            //.and().csrf().csrfTokenRepository( csrfTokenRepository() )
            //.and().addFilterAfter( new CsrfHeaderFilter(), CsrfFilter.class );
    }

    @Override
    protected void configure ( final AuthenticationManagerBuilder auth ) throws Exception {
        auth.userDetailsService( userService ).passwordEncoder( passwordEncoder );
    }

    @Override
    public void configure ( final WebSecurity web ) {
        // todo?
    }

    private CsrfTokenRepository csrfTokenRepository () {
        final HttpSessionCsrfTokenRepository repository = new HttpSessionCsrfTokenRepository();
        repository.setHeaderName( "X-XSRF-TOKEN" );
        return repository;
    }
}
