package edu.ncsu.csc.CoffeeMaker.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;

import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Inventory;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.models.Role;

public class APITest extends SecureAPITest {
    /**
     * Tests the API recipe retrieval functionality
     *
     * @throws Exception
     * @throws UnsupportedEncodingException
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.MANAGER, Role.Roles.EMPLOYEE, Role.Roles.CUSTOMER } )
    public void ensureRecipe () throws Exception {

        final String recipe = mvc.perform( get( "/api/v1/employee/recipes" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        // Check to see if the recipe we want is present
        if ( !recipe.contains( "Mocha" ) ) {
            final Recipe r = new Recipe();

            r.setName( "Mocha" );
            r.setPrice( 7 );
            final Ingredient i1 = new Ingredient( "Coffee", 8 );
            final Ingredient i2 = new Ingredient( "Milk", 8 );
            final Ingredient i3 = new Ingredient( "Sugar", 5 );
            final Ingredient i4 = new Ingredient( "Chocolate", 3 );
            r.addIngredient( i1 );
            r.addIngredient( i2 );
            r.addIngredient( i3 );
            r.addIngredient( i4 );

            final List<Ingredient> recIngredients = r.getIngredients();
            assertEquals( "Coffee", recIngredients.get( 0 ).getName() );
            assertEquals( 8, recIngredients.get( 0 ).getAmount() );
            assertEquals( "Milk", recIngredients.get( 1 ).getName() );
            assertEquals( 8, recIngredients.get( 1 ).getAmount() );
            assertEquals( "Sugar", recIngredients.get( 2 ).getName() );
            assertEquals( 5, recIngredients.get( 2 ).getAmount() );
            assertEquals( "Chocolate", recIngredients.get( 3 ).getName() );
            assertEquals( 3, recIngredients.get( 3 ).getAmount() );

            mvc.perform( post( "/api/v1/employee/recipes" ).contentType( MediaType.APPLICATION_JSON )
                    .content( TestUtils.asJsonString( r ) ) ).andExpect( status().isOk() );
        }

        final String testRecipe = mvc.perform( get( "/api/v1/employee/recipes" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        assertTrue( testRecipe.contains( "Mocha" ) );

        // Make PUT request to Inventory API endpoint

        final Inventory i = new Inventory();
        final Ingredient it1 = new Ingredient( "Coffee", 50 );
        final Ingredient it2 = new Ingredient( "Milk", 50 );
        final Ingredient it3 = new Ingredient( "Sugar", 50 );
        final Ingredient it4 = new Ingredient( "Chocolate", 50 );
        i.addIngredientToInventory( it1 );
        i.addIngredientToInventory( it2 );
        i.addIngredientToInventory( it3 );
        i.addIngredientToInventory( it4 );
        final List<Ingredient> invIngredients = i.getIngredients();

        mvc.perform( put( "/api/v1/manager/inventory" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i ) ) ).andExpect( status().isOk() );

        assertEquals( "Coffee", invIngredients.get( 0 ).getName() );
        assertEquals( 50, invIngredients.get( 0 ).getAmount() );
        assertEquals( "Milk", invIngredients.get( 1 ).getName() );
        assertEquals( 50, invIngredients.get( 1 ).getAmount() );
        assertEquals( "Sugar", invIngredients.get( 2 ).getName() );
        assertEquals( 50, invIngredients.get( 2 ).getAmount() );
        assertEquals( "Chocolate", invIngredients.get( 3 ).getName() );
        assertEquals( 50, invIngredients.get( 3 ).getAmount() );

        // Make MAKE COFFEE request to Make Coffee API endpoint

        mvc.perform( post( String.format( "/api/v1/customer/makecoffee/%s", "Mocha" ) )
                .contentType( MediaType.APPLICATION_JSON ).content( TestUtils.asJsonString( 100 ) ) )
                .andExpect( status().isOk() ).andDo( print() );
    }

    @Test
    void testName3() {
        
    }

    @Test
    void testName2() {
        
    }

    @Test
    void testName() {
        
    }

}
