package edu.ncsu.csc.CoffeeMaker.unit;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import edu.ncsu.csc.CoffeeMaker.TestConfig;
import edu.ncsu.csc.CoffeeMaker.models.User;
import edu.ncsu.csc.CoffeeMaker.models.Role;
import edu.ncsu.csc.CoffeeMaker.services.UserService;

@ExtendWith ( SpringExtension.class )
@EnableAutoConfiguration
@SpringBootTest ( classes = TestConfig.class )
public class UserServiceTest {

    @Autowired
    private UserService service;

    @Test
    @Transactional
    public void testLoadUserNonexistent () {
        Assertions.assertThrows( UsernameNotFoundException.class,
                () -> service.loadUserByUsername( "does not exist" ) );
    }

    @Test
    @Transactional
    public void testRegisterUser() {
        Assertions.assertNotNull(service.registerUser("test name", "test password", Role.CUSTOMER));
        // duplicate user
        Assertions.assertNull(service.registerUser("test name", null, null));
    }

    @Test
    @Transactional
    public void testRegisterGuest() {
        User user = service.registerGuest();
        Assertions.assertNotNull(user);
        Assertions.assertEquals("", user.getPassword());
        
        // make sure we can make multiple guests
        User user2 = service.registerGuest();
        Assertions.assertNotNull(user2);
    }

    @Test
    @Transactional
    public void testLoadUser () {
        User user = service.registerUser("test name", "test password", Role.CUSTOMER);
        Assertions.assertNotNull(user);
        final UserDetails userDetails = Assertions.assertDoesNotThrow( () -> service.loadUserByUsername( "test name" ),
                "loading user " + user.getName() + " should not cause errors" );
        Assertions.assertAll( "user from database doesn't match",
                () -> Assertions.assertEquals( user.getName(), userDetails.getUsername() ),
                () -> Assertions.assertEquals( user.getPassword(), userDetails.getPassword() ) );
    }

}
