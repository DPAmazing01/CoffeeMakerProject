package edu.ncsu.csc.CoffeeMaker.unit;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import edu.ncsu.csc.CoffeeMaker.TestConfig;
import edu.ncsu.csc.CoffeeMaker.models.CoffeeOrder;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.models.Role;
import edu.ncsu.csc.CoffeeMaker.models.User;
import edu.ncsu.csc.CoffeeMaker.services.CoffeeOrderService;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;
import edu.ncsu.csc.CoffeeMaker.services.UserService;

@ExtendWith ( SpringExtension.class )
@EnableAutoConfiguration
@SpringBootTest ( classes = TestConfig.class )
public class OrderTest {

    @Autowired
    private CoffeeOrderService orderService;

    @Autowired
    private UserService        userService;

    @Autowired
    private RecipeService      recipeService;

    @BeforeEach
    public void setup () {
        orderService.deleteAll();
        userService.deleteAll();
        recipeService.deleteAll();
    }

    @Test
    @Transactional
    public void testAddOrder () {
        final User user = createUser( "MJ_Morris", "Quarterback", Role.CUSTOMER );
        userService.save( user );

        final Recipe recipe = createRecipe( "Americano", 2, 1, 1, 0, 0 );
        recipeService.save( recipe );

        final CoffeeOrder order = new CoffeeOrder();
        order.setDate( "1" );
        order.setRecipe( recipe );
        order.setUser( user );
        order.setFulfilled( false );
        order.setPickedUp( false );

        orderService.save( order );

        final CoffeeOrder retrievedOrder = orderService.findByDate( "1" );
        Assertions.assertTrue( user.equals( retrievedOrder.getUser() ) );
        Assertions.assertTrue( recipe.equals( retrievedOrder.getRecipe() ) );
        Assertions.assertTrue( recipe.equals( retrievedOrder.getRecipe() ) );
        Assertions.assertEquals( "1", retrievedOrder.getId() );
        Assertions.assertNotNull( retrievedOrder, "The retrieved order should not be null" );
        Assertions.assertEquals( order, retrievedOrder, "The retrieved order should match the created one" );
    }

    @Test
    @Transactional
    public void testDeleteOrder () {
        final User user = createUser( "Soren Nelson", "Stage Hand", Role.EMPLOYEE );
        userService.save( user );

        final Recipe recipe = createRecipe( "Latte", 1, 2, 1, 2, 0 );
        recipeService.save( recipe );

        final CoffeeOrder order = new CoffeeOrder();
        order.setDate( "1" );
        order.setRecipe( recipe );
        order.setUser( user );
        order.setFulfilled( false );

        orderService.save( order );

        Assertions.assertEquals( 1, orderService.count(), "There should be one order in the database" );

        orderService.delete( order );

        Assertions.assertEquals( 0, orderService.findAll().size(), "There should be no orders in the CoffeeMaker" );
    }

    @Test
    @Transactional
    public void testEditOrder () {
        final User user = createUser( "Jordan Houston", "Running Back", Role.EMPLOYEE );
        userService.save( user );

        final Recipe recipe = createRecipe( "Cappuccino", 1, 1, 0, 2, 0 );
        recipeService.save( recipe );

        final CoffeeOrder order = new CoffeeOrder();
        order.setDate( "1" );
        order.setRecipe( recipe );
        order.setUser( user );
        order.setFulfilled( false );

        orderService.save( order );

        order.setFulfilled( true );

        orderService.save( order );

        order.setPickedUp( true );

        orderService.save( order );

        final CoffeeOrder retrieved = orderService.findByDate( "1" );

        Assertions.assertTrue( retrieved.isFulfilled(), "The order should be fulfilled" );
        Assertions.assertTrue( retrieved.isPickedUp(), "The order should be picked Up" );
        Assertions.assertEquals( 1, orderService.count(), "Editing an order shouldn't duplicate it" );
    }

    @Test
    @Transactional
    public void testOrderEquals () {
        final User user = createUser( "Zamurai", "Plaintext Password", Role.CUSTOMER );
        userService.save( user );

        final Recipe recipe1 = createRecipe( "Mocha", 1, 1, 1, 1, 1 );
        recipeService.save( recipe1 );

        final Recipe recipe2 = createRecipe( "Mocha", 1, 1, 1, 1, 1 );
        recipeService.save( recipe2 );

        final CoffeeOrder order1 = new CoffeeOrder();
        order1.setDate( "1" );
        order1.setRecipe( recipe1 );
        order1.setUser( user );
        order1.setFulfilled( false );

        final CoffeeOrder order2 = new CoffeeOrder();
        order2.setDate( "1" );
        order2.setRecipe( recipe2 );
        order2.setUser( user );
        order2.setFulfilled( true );

        Assertions.assertTrue( order1.equals( order2 ),
                "Orders with the same displayId, user, and recipe should be equal" );
    }

    @Test
    @Transactional
    public void testOrderToString () {
        final User user = createUser( "John Doe", "Password123", Role.CUSTOMER );
        userService.save( user );

        final Recipe recipe = createRecipe( "Cappuccino", 1, 1, 0, 2, 0 );
        recipeService.save( recipe );

        final CoffeeOrder order = new CoffeeOrder();
        order.setDate( "1" );
        order.setRecipe( recipe );
        order.setUser( user );
        order.setFulfilled( false );

        final String expectedToString = "[Order : 1] : John Doe";

        Assertions.assertEquals( expectedToString, order.toString(),
                "The toString method should return the expected string" );
    }

    private User createUser ( final String name, final String password, final Role role ) {
        final User user = new User();
        user.setName( name );
        user.setPassword( password );
        user.setRole( role );
        return user;
    }

    private Recipe createRecipe ( final String name, final Integer price, final Integer coffee, final Integer milk,
            final Integer sugar, final Integer chocolate ) {
        final Recipe recipe = new Recipe();
        recipe.setName( name );
        recipe.setPrice( price );
        final Ingredient i1 = new Ingredient( "Coffee", coffee );
        final Ingredient i2 = new Ingredient( "Milk", milk );
        final Ingredient i3 = new Ingredient( "Chocolate", chocolate );
        final Ingredient i4 = new Ingredient( "Sugar", sugar );

        recipe.addIngredient( i1 );
        recipe.addIngredient( i2 );
        recipe.addIngredient( i3 );
        recipe.addIngredient( i4 );

        return recipe;
    }
}
