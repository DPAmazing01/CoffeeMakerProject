package edu.ncsu.csc.CoffeeMaker.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.transaction.Transactional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;

import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Inventory;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.models.Role;
import edu.ncsu.csc.CoffeeMaker.services.InventoryService;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;

public class APICoffeeTest extends SecureAPITest {
    @Autowired
    private RecipeService         service;

    @Autowired
    private InventoryService      iService;

    /**
     * Sets up the tests.
     */
    @BeforeEach
    public void setup () {
        service.deleteAll();
        iService.deleteAll();

        final Inventory ivt = iService.getInventory();

        final Ingredient it1 = new Ingredient( "Coffee", 15 );
        final Ingredient it2 = new Ingredient( "Milk", 15 );
        final Ingredient it3 = new Ingredient( "Sugar", 15 );
        final Ingredient it4 = new Ingredient( "Chocolate", 15 );
        ivt.addIngredientToInventory( it1 );
        ivt.addIngredientToInventory( it2 );
        ivt.addIngredientToInventory( it3 );
        ivt.addIngredientToInventory( it4 );

        iService.save( ivt );

        final Recipe recipe = new Recipe();
        recipe.setName( "Coffee" );
        recipe.setPrice( 50 );
        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Ingredient i2 = new Ingredient( "Milk", 1 );
        final Ingredient i3 = new Ingredient( "Sugar", 1 );
        final Ingredient i4 = new Ingredient( "Chocolate", 0 );
        recipe.addIngredient( i1 );
        recipe.addIngredient( i2 );
        recipe.addIngredient( i3 );
        recipe.addIngredient( i4 );
        service.save( recipe );
    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.CUSTOMER } )
    public void testPurchaseBeverage1 () throws Exception {

        final String name = "Coffee";

        mvc.perform( post( String.format( "/api/v1/customer/makecoffee/%s", name ) )
                .contentType( MediaType.APPLICATION_JSON ).content( TestUtils.asJsonString( 60 ) ) )
                .andExpect( status().isOk() ).andExpect( jsonPath( "$.message" ).value( 10 ) );

    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.CUSTOMER } )
    public void testPurchaseBeverage2 () throws Exception {
        /* Insufficient amount paid */

        final String name = "Coffee";

        mvc.perform( post( String.format( "/api/v1/customer/makecoffee/%s", name ) )
                .contentType( MediaType.APPLICATION_JSON ).content( TestUtils.asJsonString( 40 ) ) )
                .andExpect( status().is4xxClientError() )
                .andExpect( jsonPath( "$.message" ).value( "Not enough money paid" ) );

    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.CUSTOMER } )
    public void testPurchaseBeverage3 () throws Exception {
        /* Insufficient inventory */

        final Inventory ivt = iService.getInventory();
        ivt.updateIngredient( "Coffee", 0 );
        iService.save( ivt );

        final String name = "Coffee";

        mvc.perform( post( String.format( "/api/v1/customer/makecoffee/%s", name ) )
                .contentType( MediaType.APPLICATION_JSON ).content( TestUtils.asJsonString( 50 ) ) )
                .andExpect( status().is4xxClientError() )
                .andExpect( jsonPath( "$.message" ).value( "Not enough inventory" ) );

    }

}
