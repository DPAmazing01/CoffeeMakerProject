package edu.ncsu.csc.CoffeeMaker.unit;

import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import edu.ncsu.csc.CoffeeMaker.TestConfig;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Inventory;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.InventoryService;

@ExtendWith ( SpringExtension.class )
@EnableAutoConfiguration
@SpringBootTest ( classes = TestConfig.class )
public class InventoryTest {

    @Autowired
    private InventoryService inventoryService;

    @BeforeEach
    public void setup () {
        final Inventory ivt = inventoryService.getInventory();

        final Ingredient i1 = new Ingredient( "Coffee", 500 );
        final Ingredient i2 = new Ingredient( "Milk", 500 );
        final Ingredient i3 = new Ingredient( "Sugar", 500 );
        final Ingredient i4 = new Ingredient( "Chocolate", 500 );

        ivt.addIngredientToInventory( i1 );
        ivt.addIngredientToInventory( i2 );
        ivt.addIngredientToInventory( i3 );
        ivt.addIngredientToInventory( i4 );

        inventoryService.save( ivt );
    }

    @Test
    @Transactional
    public void testConsumeInventory () {
        final Inventory i = inventoryService.getInventory();

        final Recipe recipe = new Recipe();
        recipe.setName( "Delicious Not-Coffee" );
        final Ingredient i1 = new Ingredient( "Coffee", 10 );
        final Ingredient i2 = new Ingredient( "Milk", 20 );
        final Ingredient i3 = new Ingredient( "Sugar", 5 );
        final Ingredient i4 = new Ingredient( "Chocolate", 1 );
        recipe.setPrice( 5 );
        recipe.addIngredient( i1 );
        recipe.addIngredient( i2 );
        recipe.addIngredient( i3 );
        recipe.addIngredient( i4 );

        i.useIngredients( recipe );

        /*
         * Make sure that all of the inventory fields are now properly updated
         */

        Assertions.assertEquals( 490, i.getIngredients().get( 0 ).getAmount() );
        Assertions.assertEquals( 480, i.getIngredients().get( 1 ).getAmount() );
        Assertions.assertEquals( 495, i.getIngredients().get( 2 ).getAmount() );
        Assertions.assertEquals( 499, i.getIngredients().get( 3 ).getAmount() );
    }

    @Test
    @Transactional
    public void testAddInventory1 () {
        Inventory ivt = inventoryService.getInventory();
        final ArrayList<Ingredient> newInt = new ArrayList<Ingredient>();
        final Ingredient i1 = new Ingredient( "Coffee", 5 );
        final Ingredient i2 = new Ingredient( "Milk", 3 );
        final Ingredient i3 = new Ingredient( "Sugar", 7 );
        final Ingredient i4 = new Ingredient( "Chocolate", 2 );

        newInt.add( i1 );
        newInt.add( i2 );
        newInt.add( i3 );
        newInt.add( i4 );

        ivt.addIngredients( newInt );

        /* Save and retrieve again to update with DB */
        inventoryService.save( ivt );

        ivt = inventoryService.getInventory();

        Assertions.assertEquals( 505, ivt.getIngredients().get( 0 ).getAmount(),
                "Adding to the inventory should result in correctly-updated values for coffee" );
        Assertions.assertEquals( 503, ivt.getIngredients().get( 1 ).getAmount(),
                "Adding to the inventory should result in correctly-updated values for milk" );
        Assertions.assertEquals( 507, ivt.getIngredients().get( 2 ).getAmount(),
                "Adding to the inventory should result in correctly-updated values sugar" );
        Assertions.assertEquals( 502, ivt.getIngredients().get( 3 ).getAmount(),
                "Adding to the inventory should result in correctly-updated values chocolate" );

    }

    @Test
    @Transactional
    public void testAddInventory2 () {
        final Inventory ivt = inventoryService.getInventory();

        try {
            final ArrayList<Ingredient> newInt = new ArrayList<Ingredient>();
            final Ingredient i1 = new Ingredient( "Coffee", -5 );
            final Ingredient i2 = new Ingredient( "Milk", 3 );
            final Ingredient i3 = new Ingredient( "Sugar", 7 );
            final Ingredient i4 = new Ingredient( "Chocolate", 2 );

            newInt.add( i1 );
            newInt.add( i2 );
            newInt.add( i3 );
            newInt.add( i4 );
        }
        catch ( final IllegalArgumentException iae ) {
            Assertions.assertEquals( 500, ivt.getIngredients().get( 0 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for coffee should result in no changes -- coffee" );
            Assertions.assertEquals( 500, ivt.getIngredients().get( 1 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for coffee should result in no changes -- milk" );
            Assertions.assertEquals( 500, ivt.getIngredients().get( 2 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for coffee should result in no changes -- sugar" );
            Assertions.assertEquals( 500, ivt.getIngredients().get( 3 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for coffee should result in no changes -- chocolate" );
        }
    }

    @Test
    @Transactional
    public void testAddInventory3 () {
        final Inventory ivt = inventoryService.getInventory();

        try {
            final ArrayList<Ingredient> newInt = new ArrayList<Ingredient>();
            final Ingredient i1 = new Ingredient( "Coffee", 5 );
            final Ingredient i2 = new Ingredient( "Milk", -3 );
            final Ingredient i3 = new Ingredient( "Sugar", 7 );
            final Ingredient i4 = new Ingredient( "Chocolate", 2 );

            newInt.add( i1 );
            newInt.add( i2 );
            newInt.add( i3 );
            newInt.add( i4 );
        }
        catch ( final IllegalArgumentException iae ) {
            Assertions.assertEquals( 500, ivt.getIngredients().get( 0 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for milk should result in no changes -- coffee" );
            Assertions.assertEquals( 500, ivt.getIngredients().get( 1 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for milk should result in no changes -- milk" );
            Assertions.assertEquals( 500, ivt.getIngredients().get( 2 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for milk should result in no changes -- sugar" );
            Assertions.assertEquals( 500, ivt.getIngredients().get( 3 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for milk should result in no changes -- chocolate" );

        }

    }

    @Test
    @Transactional
    public void testAddInventory4 () {
        final Inventory ivt = inventoryService.getInventory();

        try {
            final ArrayList<Ingredient> newInt = new ArrayList<Ingredient>();
            final Ingredient i1 = new Ingredient( "Coffee", 5 );
            final Ingredient i2 = new Ingredient( "Milk", 3 );
            final Ingredient i3 = new Ingredient( "Sugar", -7 );
            final Ingredient i4 = new Ingredient( "Chocolate", 2 );

            newInt.add( i1 );
            newInt.add( i2 );
            newInt.add( i3 );
            newInt.add( i4 );
        }
        catch ( final IllegalArgumentException iae ) {
            Assertions.assertEquals( 500, ivt.getIngredients().get( 0 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for sugar should result in no changes -- coffee" );
            Assertions.assertEquals( 500, ivt.getIngredients().get( 1 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for sugar should result in no changes -- milk" );
            Assertions.assertEquals( 500, ivt.getIngredients().get( 2 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for sugar should result in no changes -- sugar" );
            Assertions.assertEquals( 500, ivt.getIngredients().get( 3 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for sugar should result in no changes -- chocolate" );

        }

    }

    @Test
    @Transactional
    public void testAddInventory5 () {
        final Inventory ivt = inventoryService.getInventory();

        try {
            final ArrayList<Ingredient> newInt = new ArrayList<Ingredient>();
            final Ingredient i1 = new Ingredient( "Coffee", 5 );
            final Ingredient i2 = new Ingredient( "Milk", 3 );
            final Ingredient i3 = new Ingredient( "Sugar", 7 );
            final Ingredient i4 = new Ingredient( "Chocolate", -2 );

            newInt.add( i1 );
            newInt.add( i2 );
            newInt.add( i3 );
            newInt.add( i4 );
        }
        catch ( final IllegalArgumentException iae ) {
            Assertions.assertEquals( 500, ivt.getIngredients().get( 0 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for chocolate should result in no changes -- coffee" );
            Assertions.assertEquals( 500, ivt.getIngredients().get( 0 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for chocolate should result in no changes -- milk" );
            Assertions.assertEquals( 500, ivt.getIngredients().get( 0 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for chocolate should result in no changes -- sugar" );
            Assertions.assertEquals( 500, ivt.getIngredients().get( 0 ).getAmount(),
                    "Trying to update the Inventory with an invalid value for chocolate should result in no changes -- chocolate" );

        }

    }

    /*
     * Tests checkAmount to see if it can catch Strings that aren't positive
     * integers
     */
    @Test
    @Transactional
    public void testCheckAmount () {
        final Inventory ivt = inventoryService.getInventory();
        try {
            ivt.checkAmount( "five" );
        }
        catch ( final IllegalArgumentException iae ) {
            Assertions.assertEquals( iae.getMessage(), "Units must be a positive integer" );
        }
        try {
            ivt.checkAmount( "-5" );
        }
        catch ( final IllegalArgumentException iae ) {
            Assertions.assertEquals( iae.getMessage(), "Units must be a positive integer" );
        }
    }

    /*
     * Tests updating the value of a single ingredient
     */
    @Test
    @Transactional
    public void testUpdateIngredient () {
        final Inventory ivt = inventoryService.getInventory();
        ivt.updateIngredient( "Coffee", 400 );
        Assertions.assertEquals( 400, ivt.getIngredients().get( 0 ).getAmount() );
        try {
            ivt.updateIngredient( "Coffee", -400 );
        }
        catch ( final IllegalArgumentException iae ) {
            Assertions.assertEquals( 400, ivt.getIngredients().get( 0 ).getAmount() );
        }

    }

}
