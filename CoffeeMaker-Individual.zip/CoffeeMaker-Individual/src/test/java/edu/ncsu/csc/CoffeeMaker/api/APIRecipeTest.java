package edu.ncsu.csc.CoffeeMaker.api;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;

import edu.ncsu.csc.CoffeeMaker.models.Role;

public class APIRecipeTest extends SecureAPITest {

    @Autowired
    private RecipeService         service;

    /**
     * Sets up the tests.
     */
    @BeforeEach
    public void setup () {
        service.deleteAll();
    }

    @Test
    @Transactional
    @WithMockUser ( roles = { "EMPLOYEE" } )
    public void ensureRecipe () throws Exception {
        service.deleteAll();

        final Recipe r = new Recipe();
        final Ingredient i1 = new Ingredient( "Coffee", 5 );
        final Ingredient i2 = new Ingredient( "Milk", 3 );
        final Ingredient i3 = new Ingredient( "Chocolate", 2 );
        final Ingredient i4 = new Ingredient( "Sugar", 5 );
        final Ingredient i5 = new Ingredient( "Cinnamon", 6 );

        r.addIngredient( i1 );
        r.addIngredient( i2 );
        r.addIngredient( i3 );
        r.addIngredient( i4 );
        r.addIngredient( i5 );
        r.setPrice( 10 );
        r.setName( "Mocha" );

        mvc.perform( post( "/api/v1/employee/recipes" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r ) ) ).andExpect( status().isOk() );

    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testRecipeAPI () throws Exception {

        service.deleteAll();

        final Recipe recipe = new Recipe();
        recipe.setName( "Delicious Not-Coffee" );
        recipe.setPrice( 5 );
        final Ingredient i1 = new Ingredient( "Coffee", 5 );
        final Ingredient i2 = new Ingredient( "Milk", 3 );
        final Ingredient i3 = new Ingredient( "Chocolate", 2 );
        final Ingredient i4 = new Ingredient( "Sugar", 5 );
        final Ingredient i5 = new Ingredient( "Cinnamon", 6 );

        recipe.addIngredient( i1 );
        recipe.addIngredient( i2 );
        recipe.addIngredient( i3 );
        recipe.addIngredient( i4 );
        recipe.addIngredient( i5 );

        mvc.perform( post( "/api/v1/employee/recipes" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( recipe ) ) );

        Assertions.assertEquals( 1, (int) service.count() );

    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testAddRecipe2 () throws Exception {

        /* Tests a recipe with a duplicate name to make sure it's rejected */

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );
        final String name = "Coffee";
        final Recipe r1 = createRecipe( name, 50, 3, 1, 1, 0, 3 );

        service.save( r1 );

        final Recipe r2 = createRecipe( name, 50, 3, 1, 1, 0, 2 );
        mvc.perform( post( "/api/v1/employee/recipes" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r2 ) ) ).andExpect( status().is4xxClientError() );

        Assertions.assertEquals( 1, service.findAll().size(), "There should only one recipe in the CoffeeMaker" );
    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testAddRecipe15 () throws Exception {

        /* Tests to make sure that our cap of 3 recipes is enforced */

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Recipe r1 = createRecipe( "Coffee", 50, 3, 1, 1, 0, 4 );
        service.save( r1 );
        final Recipe r2 = createRecipe( "Mocha", 50, 3, 1, 1, 2, 5 );
        service.save( r2 );
        final Recipe r3 = createRecipe( "Latte", 60, 3, 2, 2, 0, 8 );
        service.save( r3 );

        Assertions.assertEquals( 3, service.count(),
                "Creating three recipes should result in three recipes in the database" );

        final Recipe r4 = createRecipe( "Hot Chocolate", 75, 0, 2, 1, 2, 7 );

        mvc.perform( post( "/api/v1/employee/recipes" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r4 ) ) ).andExpect( status().isInsufficientStorage() );

        Assertions.assertEquals( 3, service.count(), "Creating a fourth recipe should not get saved" );
    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testDeleteRecipe () throws Exception {

        /* Test to make sure a recipe can be deleted */
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Recipe r1 = createRecipe( "Coffee", 50, 3, 1, 1, 0, 2 );

        mvc.perform( post( "/api/v1/employee/recipes" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r1 ) ) ).andExpect( status().isOk() );

        Assertions.assertEquals( 1, service.count(), "There should be one recipe in the database" );

        mvc.perform( delete( "/api/v1/employee/recipes/Coffee" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r1 ) ) ).andExpect( status().is2xxSuccessful() );

        Assertions.assertEquals( 0, service.count(), "Only recipe in database should be deleted" );

    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testDeleteFromMultipleRecipes () throws Exception {

        /* Test to make sure a recipe can be deleted */
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Recipe r1 = createRecipe( "Coffee", 50, 3, 1, 1, 0, 4 );
        service.save( r1 );
        final Recipe r2 = createRecipe( "Mocha", 60, 4, 4, 2, 1, 7 );
        service.save( r2 );
        final Recipe r3 = createRecipe( "Tea", 70, 1, 1, 1, 1, 6 );
        service.save( r3 );

        Assertions.assertEquals( 3, service.count(), "There should be three recipe in the database" );

        mvc.perform( delete( "/api/v1/employee/recipes/Mocha" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r1 ) ) ).andExpect( status().is2xxSuccessful() );

        Assertions.assertEquals( 2, service.count(), "Mocha should be deleted from the database" );

        final String testRecipe = mvc.perform( get( "/api/v1/employee/recipes" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        assertFalse( testRecipe.contains( "Mocha" ) );
        assertTrue( testRecipe.contains( "Coffee" ) );
        assertTrue( testRecipe.contains( "Tea" ) );

    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testDeleteMultipleRecipes () throws Exception {

        /* Test to make sure a recipe can be deleted */
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Recipe r1 = createRecipe( "Hot Chocolate", 50, 3, 1, 1, 0, 4 );
        service.save( r1 );
        final Recipe r2 = createRecipe( "Mocha", 60, 4, 4, 2, 1, 7 );
        service.save( r2 );
        final Recipe r3 = createRecipe( "Tea", 70, 1, 1, 1, 1, 6 );
        service.save( r3 );

        Assertions.assertEquals( 3, service.count(), "There should be three recipe in the database" );

        mvc.perform( delete( "/api/v1/employee/recipes/Tea" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r1 ) ) ).andExpect( status().is2xxSuccessful() );

        mvc.perform( delete( "/api/v1/employee/recipes/Hot Chocolate" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r1 ) ) ).andExpect( status().is2xxSuccessful() );

        Assertions.assertEquals( 1, service.count(), "Only Mocha should be in the database" );

        final String testRecipe = mvc.perform( get( "/api/v1/employee/recipes" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        assertTrue( testRecipe.contains( "Mocha" ) );
        assertFalse( testRecipe.contains( "Hot Chocolate" ) );
        assertFalse( testRecipe.contains( "Tea" ) );

    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testEditRecipe () throws Exception {

        /* Test to make sure a recipe can be deleted */
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Recipe r1 = createRecipe( "Hot Chocolate", 50, 3, 1, 1, 0, 4 );
        service.save( r1 );
        final Recipe r2 = createRecipe( "Mocha", 60, 4, 4, 2, 1, 7 );
        service.save( r2 );

        Assertions.assertEquals( 2, service.count(), "There should be three recipe in the database" );

        final Recipe r3 = createRecipe( "Mocha", 70, 1, 1, 1, 1, 6 );

        mvc.perform( put( "/api/v1/employee/recipes" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r3 ) ) ).andExpect( status().is2xxSuccessful() );

        Assertions.assertEquals( 2, service.count(), "Only two recipes should be in the database" );

        final String testRecipe = mvc.perform( get( "/api/v1/employee/recipes/Mocha" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        assertTrue( testRecipe.contains( "Mocha" ) );
        assertTrue( testRecipe.contains( "70" ) );
    }

    private Recipe createRecipe ( final String name, final Integer price, final Integer coffee, final Integer milk,
            final Integer sugar, final Integer chocolate, final Integer cinnamon ) {
        final Recipe recipe = new Recipe();
        recipe.setName( name );
        recipe.setPrice( price );
        final Ingredient i1 = new Ingredient( "Coffee", coffee );
        final Ingredient i2 = new Ingredient( "Milk", milk );
        final Ingredient i3 = new Ingredient( "Chocolate", chocolate );
        final Ingredient i4 = new Ingredient( "Sugar", sugar );
        final Ingredient i5 = new Ingredient( "Cinnamon", cinnamon );

        recipe.addIngredient( i1 );
        recipe.addIngredient( i2 );
        recipe.addIngredient( i3 );
        recipe.addIngredient( i4 );
        recipe.addIngredient( i5 );

        return recipe;
    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.CUSTOMER } )
    public void testGetRecipesCustomer () throws Exception {

        /* Test to make sure a recipe can be deleted */
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Recipe r1 = createRecipe( "Hot Chocolate", 50, 3, 1, 1, 0, 4 );
        service.save( r1 );
        final Recipe r2 = createRecipe( "Mocha", 60, 4, 4, 2, 1, 7 );
        service.save( r2 );

        final String testRecipes = mvc.perform( get( "/api/v1/customer/recipes/" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        assertTrue( testRecipes.contains( "Mocha" ) );
        assertTrue( testRecipes.contains( "60" ) );
        assertTrue( testRecipes.contains( "Hot Chocolate" ) );
        assertTrue( testRecipes.contains( "50" ) );
    }
}
