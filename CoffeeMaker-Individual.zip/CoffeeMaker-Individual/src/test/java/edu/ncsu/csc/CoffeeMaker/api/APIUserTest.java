package edu.ncsu.csc.CoffeeMaker.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.controllers.APIController;
import edu.ncsu.csc.CoffeeMaker.controllers.APIUserController;
import edu.ncsu.csc.CoffeeMaker.models.Role;
import edu.ncsu.csc.CoffeeMaker.models.User;
import edu.ncsu.csc.CoffeeMaker.services.UserService;

public class APIUserTest extends SecureAPITest {
    @Autowired
    private UserService service;

    /**
     * Sets up the tests.
     */
    @BeforeEach
    public void setup () {
        service.deleteAll();
    }

    /**
     * @return a mocked user for testing
     */
    static User mockUser () {
        final User user = new User();
        user.setName( "TestUser" );
        user.setPassword( "TestPassword" );
        return user;
    }

    /**
     * Perform a register to the given endpoint
     *
     * @param endpoint
     *            the register endpoint
     * @param user
     *            the user to pass to the endpoint
     */
    ResultActions performRegister ( final String endpoint, final User user ) throws Exception {
        return mvc.perform(
                post( endpoint ).contentType( MediaType.APPLICATION_JSON ).content( TestUtils.asJsonString( user ) ) );
    }

    /**
     * Attempt to register a mock user
     *
     * @param endpoint
     *            the login endpoint
     * @param role
     *            the expected role to be logged in as
     */
    void assertRegister ( final String endpoint, final Role role ) throws Exception {
        final User user = mockUser();
        performRegister( endpoint, user ).andExpect( status().isCreated() );
        final User u = service.findByName( user.getName() );
        Assertions.assertNotNull( u );
        Assertions.assertEquals( role, u.getRole() );
    }

    /**
     * Create a valid user and POST it, ensuring the correct HTTP response is
     * returned.
     *
     * @throws Exception
     */
    @Test
    @Transactional
    public void testRegisterCustomer () throws Exception {
        assertRegister( APIUserController.REGISTER_CUSTOMER_ENDPOINT, Role.CUSTOMER );
    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.MANAGER } )
    public void testRegisterEmployee () throws Exception {
        assertRegister( APIUserController.REGISTER_EMPLOYEE_ENDPOINT, Role.EMPLOYEE );
    }

    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testRegisterInvalid () throws Exception {
        final User user = mockUser();
        performRegister( APIUserController.REGISTER_EMPLOYEE_ENDPOINT, user ).andExpect( status().isForbidden() );
    }

    /*
     * Tests an user with a duplicate value to make sure it's rejected. A
     * duplicate user is defined as any that shares the same user name,
     * regardless of role or password.
     */
    @Test
    @Transactional
    public void testRegisterDuplicate () throws Exception {
        final User user = mockUser();
        Assertions.assertNotNull( service.registerUser( user.getName(), "", Role.CUSTOMER ) );
        // duplicate registration should fail
        performRegister( APIUserController.REGISTER_CUSTOMER_ENDPOINT, user ).andExpect( status().isConflict() );
    }

    /*
     * Tests an retrieving all a added users
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testGetUsers () throws Exception {

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Users in the CoffeeMaker" );
        final User u = new User();

        u.setName( "TestUser" );
        u.setPassword( "TestPassword" );
        u.setRole( Role.CUSTOMER );

        service.save( u );

        final String user = mvc.perform( get( APIController.EMPLOYEE_PATH + "users" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        Assertions.assertEquals( 1, service.findAll().size(), "There should only one recipe in the CoffeeMaker" );
    }

    /*
     * Tests an retrieving a specific user
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testGetUser () throws Exception {

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Users in the CoffeeMaker" );
        final User u = new User();

        u.setName( "TestUser" );
        u.setPassword( "TestPassword" );
        u.setRole( Role.CUSTOMER );

        service.save( u );

        final String user = mvc.perform( get( APIController.EMPLOYEE_PATH + "users/TestUser" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        Assertions.assertTrue( user.contains( "TestUser" ) );

        // Attempt to get an non-existent user.
        final String fakeUser = mvc.perform( get( APIController.EMPLOYEE_PATH + "users/NotReal" ) ).andDo( print() )
                .andExpect( status().is4xxClientError() ).andReturn().getResponse().getContentAsString();

    }

    /*
     * Tests deleting a specific user
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testDeleteUser () throws Exception {

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Users in the CoffeeMaker" );
        final User u = new User();

        u.setName( "TestUser" );
        u.setPassword( "TestPassword" );
        u.setRole( Role.CUSTOMER );

        service.save( u );

        final String user = mvc.perform( delete( APIController.EMPLOYEE_PATH + "users/TestUser" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Users in the CoffeeMaker" );

        // Repeat the same call, it shouldn't work.

        final String fake = mvc.perform( delete( APIController.EMPLOYEE_PATH + "users/TestUser" ) ).andDo( print() )
                .andExpect( status().is4xxClientError() ).andReturn().getResponse().getContentAsString();

    }

    /*
     * Tests a updating a specific user //
     */
    // @Test
    // @Transactional
    // public void testUpdateUser () throws Exception {
    //
    // Assertions.assertEquals( 0, service.findAll().size(), "There should be no
    // Users in the CoffeeMaker" );
    // final User u = new User();
    //
    // u.setName( "TestUser" );
    // u.setPassword( "TestPassword" );
    // u.setRole( Role.CUSTOMER );
    //
    // service.save( u );
    //
    // final User u2 = new User();
    //
    // u2.setName( "TestUser" );
    // u2.setPassword( "TestPassword" );
    // u2.setRole( Role.EMPLOYEE );
    //
    // final String user = mvc
    // .perform( put( "/api/v1/users" ).contentType( MediaType.APPLICATION_JSON
    // )
    // .content( TestUtils.asJsonString( u2 ) ) )
    // .andExpect( status().isOk()
    // ).andReturn().getResponse().getContentAsString();
    //
    // Assertions.assertTrue( user.contains( "EMPLOYEE" ) );
    //
    // // Cannot update user that doesn't exist
    //
    // u2.setName( "FakeUser" );
    // u2.setPassword( "TestPassword" );
    // u2.setRole( Role.EMPLOYEE );
    //
    // final String fake = mvc
    // .perform( put( "/api/v1/users" ).contentType( MediaType.APPLICATION_JSON
    // )
    // .content( TestUtils.asJsonString( u2 ) ) )
    // .andExpect( status().is4xxClientError()
    // ).andReturn().getResponse().getContentAsString();
    // }

    /**
     * Tests the roles
     *
     * @throws Exception
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.CUSTOMER } )
    public void testRole () throws Exception {
        mvc.perform( MockMvcRequestBuilders.get( APIController.PROTECTED_PATH + "role" ) )
                .andExpect( MockMvcResultMatchers.status().isOk() )
                .andExpect( MockMvcResultMatchers.content().string( Role.Roles.CUSTOMER ) );
    }

    /**
     * Tests the roles
     *
     * @throws Exception
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.CUSTOMER } )
    public void testRole2 () throws Exception {
        mvc.perform( MockMvcRequestBuilders.get( APIController.PROTECTED_PATH + "role" ) )
                .andExpect( MockMvcResultMatchers.status().isOk() )
                .andExpect( MockMvcResultMatchers.content().string( Role.Roles.CUSTOMER ) );
    }

    /**
     * Tests unauthorized users
     *
     * @throws Exception
     */
    @Test
    @Transactional
    @WithMockUser ( roles = {} )
    public void testRoleForbidden () throws Exception {

        mvc.perform( MockMvcRequestBuilders.get( APIController.PROTECTED_PATH + "role" ) )
                .andExpect( MockMvcResultMatchers.status().isForbidden() );
    }
}
