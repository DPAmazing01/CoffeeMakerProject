package edu.ncsu.csc.CoffeeMaker.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;

import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Role;
import edu.ncsu.csc.CoffeeMaker.services.IngredientService;

public class APIIngredientTest extends SecureAPITest {
    @Autowired
    private IngredientService     service;

    /**
     * Sets up the tests.
     */
    @BeforeEach
    public void setup () {
        service.deleteAll();
    }

    /**
     * Create a valid ingredient and POST it, ensuring the correct HTTP response
     * is returned.
     *
     * @throws Exception
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void ensureIngredient () throws Exception {
        final Ingredient i = new Ingredient();

        i.setName( "Coffee" );
        i.setAmount( 5 );

        mvc.perform( post( "/api/v1/employee/ingredients" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i ) ) ).andExpect( status().isCreated() );

    }

    /**
     * Create a valid ingredient and POST it, ensuring the IngredientService is
     * updated.
     *
     * @throws Exception
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testIngredientAPI () throws Exception {
        final Ingredient i = new Ingredient();

        i.setName( "Coffee" );
        i.setAmount( 5 );

        mvc.perform( post( "/api/v1/employee/ingredients" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i ) ) ).andExpect( status().isCreated() );

        Assertions.assertEquals( 1, (int) service.count() );

    }

    /*
     * Tests an ingredient with a duplicate value to make sure it's rejected
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testAddIngredient () throws Exception {

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Ingredients in the CoffeeMaker" );
        final Ingredient i = new Ingredient();
        i.setAmount( 5 );
        i.setName( "Coffee" );

        service.save( i );

        final Ingredient i2 = new Ingredient();
        i2.setAmount( 5 );
        i2.setName( "Coffee" );

        mvc.perform( post( "/api/v1/employee/ingredients" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i2 ) ) ).andExpect( status().is4xxClientError() );

        Assertions.assertEquals( 1, service.findAll().size(), "There should only one recipe in the CoffeeMaker" );
    }

    /*
     * Tests an retrieving all a added ingredients
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testGetIngredients () throws Exception {

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Ingredients in the CoffeeMaker" );
        final Ingredient i = new Ingredient();
        i.setAmount( 5 );
        i.setName( "Coffee" );

        service.save( i );

        final String ingr = mvc.perform( get( "/api/v1/employee/ingredients" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        Assertions.assertEquals( 1, service.findAll().size(), "There should only one recipe in the CoffeeMaker" );
    }

    /*
     * Tests an retrieving a specific ingredient
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testGetIngredient () throws Exception {

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Ingredients in the CoffeeMaker" );
        final Ingredient i = new Ingredient();
        i.setAmount( 5 );
        i.setName( "Coffee" );

        service.save( i );

        final String ingr = mvc.perform( get( "/api/v1/employee/ingredients/COFFEE" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        Assertions.assertTrue( ingr.contains( "5" ) );
    }

    /*
     * Tests deleting a specific ingredient
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testDeleteIngredient () throws Exception {

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Ingredients in the CoffeeMaker" );
        final Ingredient i = new Ingredient();
        i.setAmount( 5 );
        i.setName( "Coffee" );

        service.save( i );

        final String ingr = mvc.perform( delete( "/api/v1/employee/ingredients/COFFEE" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Ingredients in the CoffeeMaker" );
    }

    /*
     * Tests a updating a specific ingredient
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.EMPLOYEE } )
    public void testUpdateIngredient () throws Exception {

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Ingredients in the CoffeeMaker" );
        final Ingredient i = new Ingredient();
        i.setAmount( 5 );
        i.setName( "Coffee" );

        service.save( i );

        final Ingredient i2 = new Ingredient();
        i2.setAmount( 17 );
        i2.setName( "Coffee" );

        final String ingr = mvc
                .perform( put( "/api/v1/employee/ingredients" ).contentType( MediaType.APPLICATION_JSON )
                        .content( TestUtils.asJsonString( i2 ) ) )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        Assertions.assertTrue( ingr.contains( "17" ) );
    }
}
