package edu.ncsu.csc.CoffeeMaker;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;

@ExtendWith ( SpringExtension.class )
@EnableAutoConfiguration
@SpringBootTest ( classes = TestConfig.class )
public class TestDatabaseInteraction {
    @Autowired
    private RecipeService recipeService;

    /**
     * Sets up the tests.
     */
    @BeforeEach
    public void setup () {
        recipeService.deleteAll();
    }

    /**
     * Tests the RecipeService class
     */
    @Test
    @Transactional
    public void testRecipes () {
        final Recipe r = new Recipe();

        r.setName( "Sweet Tea" );
        r.setPrice( 7 );

        recipeService.save( r );

        final List<Recipe> dbRecipes = recipeService.findAll();

        assertEquals( 1, dbRecipes.size() );

        final Recipe dbRecipe = dbRecipes.get( 0 );

        assertEquals( "Sweet Tea", dbRecipe.getName() );
        assertEquals( 7, dbRecipe.getPrice() );
    }

    /**
     * Tests the RecipeService.findByName() method
     */
    @Test
    @Transactional
    public void testFindByName () {
        final Recipe r = new Recipe();

        r.setName( "Sweet Tea" );
        r.setPrice( 7 );

        recipeService.save( r );

        final Recipe dbRecipe = recipeService.findByName( "Sweet Tea" );

        assertEquals( "Sweet Tea", dbRecipe.getName() );
        assertEquals( 7, dbRecipe.getPrice() );
    }

    /**
     * Tests Edit Recipe functionality
     */
    @Test
    @Transactional
    public void testEditRecipe () {

        final Recipe r = new Recipe();

        r.setName( "Sweet Tea" );
        r.setPrice( 7 );

        recipeService.save( r );

        final Recipe dbRecipe = recipeService.findByName( "Sweet Tea" );

        dbRecipe.setPrice( 15 );

        recipeService.save( dbRecipe );

        assertEquals( 1, recipeService.count() );

        final List<Recipe> dbRecipes = recipeService.findAll();

        assertEquals( 1, dbRecipes.size() );

        assertEquals( "Sweet Tea", dbRecipe.getName() );
        assertEquals( 15, dbRecipe.getPrice() );
    }

    /**
     * Tests creating recipe with ingredients functionality
     */
    @Test
    @Transactional
    public void testCreateRecipeWithIngredients () {
        final Recipe r1 = new Recipe();
        r1.setName( "Delicious Coffee" );

        r1.setPrice( 50 );

        r1.addIngredient( new Ingredient( "Coffee", 10 ) );
        r1.addIngredient( new Ingredient( "Pumpkin Spice", 3 ) );
        r1.addIngredient( new Ingredient( "Milk", 2 ) );

        recipeService.save( r1 );

        assertEquals( "Delicious Coffee", r1.getName() );
        assertEquals( 50, r1.getPrice() );
        final List<Ingredient> ingredients = r1.getIngredients();
        assertEquals( "Coffee", ingredients.get( 0 ).getName() );
        assertEquals( 10, ingredients.get( 0 ).getAmount() );
        assertEquals( "Pumpkin Spice", ingredients.get( 1 ).getName() );
        assertEquals( 3, ingredients.get( 1 ).getAmount() );
        assertEquals( "Milk", ingredients.get( 2 ).getName() );
        assertEquals( 2, ingredients.get( 2 ).getAmount() );
    }
}
