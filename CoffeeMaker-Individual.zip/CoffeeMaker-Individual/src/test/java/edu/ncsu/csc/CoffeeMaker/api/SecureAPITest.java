package edu.ncsu.csc.CoffeeMaker.api;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import edu.ncsu.csc.CoffeeMaker.models.Role;

/**
 * Extend this class to write API tests with the security configuration
 */
@ExtendWith ( SpringExtension.class )
@SpringBootTest
@AutoConfigureMockMvc
public class SecureAPITest {
    static final String AUTHORIZED_ROLE = Role.Roles.CUSTOMER;

    /**
     * MockMvc uses Spring's testing framework to handle requests to the REST
     * API
     */
    protected MockMvc               mvc;

    @Autowired
    protected WebApplicationContext context;

    /**
     * Sets up the tests.
     */
    @BeforeEach
    public final void setupMvc () {
        mvc = MockMvcBuilders.webAppContextSetup(context).apply(SecurityMockMvcConfigurers.springSecurity()).build();
    }
}
