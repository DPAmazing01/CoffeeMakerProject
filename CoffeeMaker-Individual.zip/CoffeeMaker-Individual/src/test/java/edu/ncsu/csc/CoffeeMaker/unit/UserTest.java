package edu.ncsu.csc.CoffeeMaker.unit;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import edu.ncsu.csc.CoffeeMaker.TestConfig;
import edu.ncsu.csc.CoffeeMaker.models.Role;
import edu.ncsu.csc.CoffeeMaker.models.User;
import edu.ncsu.csc.CoffeeMaker.services.UserService;

@ExtendWith ( SpringExtension.class )
@EnableAutoConfiguration
@SpringBootTest ( classes = TestConfig.class )
public class UserTest {

    @Autowired
    private UserService service;

    @BeforeEach
    public void setup () {
        service.deleteAll();
    }

    @Test
    @Transactional
    public void testAddUser () {

        final User u1 = new User();
        u1.setName( "MJ_Morris" );
        u1.setPassword( "Quarterback" );
        u1.setRole( Role.CUSTOMER );

        service.save( u1 );

        final User u2 = new User();
        u1.setName( "KC_Concepcion" );
        u1.setPassword( "Wide Receiver" );
        u1.setRole( Role.EMPLOYEE );

        service.save( u2 );

        final List<User> users = service.findAll();
        Assertions.assertEquals( 2, users.size(), "Creating two users should result in two users in the database" );

        Assertions.assertEquals( u2, users.get( 0 ), "The retrieved user should match the created one" );
    }

    @Test
    @Transactional
    public void testAddUser1 () {

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Users in the CoffeeMaker" );
        final String name = "Peyton Wilson";
        final User u1 = createUser( "Peyton Wilson", "Linebacker", Role.CUSTOMER );

        service.save( u1 );

        Assertions.assertEquals( 1, service.findAll().size(), "There should only one user in the CoffeeMaker" );
        Assertions.assertNotNull( service.findByName( name ) );

    }

    /**
     * Test to ensure adding a duplicate username will overwrite the existing user
     */
    @Test
    @Transactional
    public void testAddUserDuplicate () {
        final User existingUser = createUser( "Peyton Wilson", "Linebacker", Role.CUSTOMER );
        service.save( existingUser );

        final User newUser = new User();
        newUser.setName(existingUser.getName());
        newUser.setRole(Role.EMPLOYEE);
        Assertions.assertNotEquals(existingUser.getRole(), newUser.getRole(), "For testing purposes the new and old users should have different roles");
        newUser.setPassword("new password");
        service.save( newUser );

        List<User> actual = service.findAll();
        Assertions.assertEquals(1, actual.size(), "There should only be one user in the system after adding the duplicate user");
        User actualUser = actual.get(0);
        // check that the user from the database is equal to the new user
        Assertions.assertAll(
                () -> Assertions.assertEquals(actualUser.getName(), newUser.getName()),
                () -> Assertions.assertEquals(actualUser.getRole(), newUser.getRole()),
                () -> Assertions.assertEquals(actualUser.getPassword(), newUser.getPassword())
                );
    }

    @Test
    @Transactional
    public void testDeleteUser () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no users in the CoffeeMaker" );

        final User u1 = createUser( "Soren Nelson", "Stage Hand", Role.EMPLOYEE );
        service.save( u1 );

        Assertions.assertEquals( 1, service.count(), "There should be one user in the database" );

        service.delete( u1 );
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Users in the CoffeeMaker" );
    }

    @Test
    @Transactional
    public void testDeleteUser2 () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Users in the CoffeeMaker" );

        final User u1 = createUser( "Kendrick Raphael", "Running Back", Role.EMPLOYEE );
        service.save( u1 );
        final User u2 = createUser( "Ayden White", "Cornerback", Role.CUSTOMER );
        service.save( u2 );
        final User u3 = createUser( "Devin Vann", "Linebacker", Role.CUSTOMER );
        service.save( u3 );

        Assertions.assertEquals( 3, service.count(), "There should be three users in the database" );

        service.deleteAll();

        Assertions.assertEquals( 0, service.count(), "`service.deleteAll()` should remove everything" );

    }

    @Test
    @Transactional
    public void testDeleteUser_DatabaseInteraction1 () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Users in the CoffeeMaker" );

        // Delete the first item added.

        final User u1 = createUser( "Kendrick Raphael", "Running Back", Role.EMPLOYEE );
        service.save( u1 );
        final User u2 = createUser( "Ayden White", "Cornerback", Role.CUSTOMER );
        service.save( u2 );
        final User u3 = createUser( "Devin Vann", "Linebacker", Role.CUSTOMER );
        service.save( u3 );

        Assertions.assertEquals( 3, service.count(), "There should be three users in the database" );

        service.delete( u1 );

        final List<User> dbUsers = service.findAll();

        Assertions.assertEquals( 2, service.count(), "There should be two users in the database." );

        for ( int i = 0; i < service.count(); i++ ) {
            Assertions.assertTrue( dbUsers.get( i ).equals( u2 ) || dbUsers.get( i ).equals( u3 ) );
        }

    }

    @Test
    @Transactional
    public void testDeleteUser_DatabaseInteraction2 () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Users in the CoffeeMaker" );

        // Delete the item in the middle.

        final User u1 = createUser( "Kendrick Raphael", "Running Back", Role.EMPLOYEE );
        service.save( u1 );
        final User u2 = createUser( "Ayden White", "Cornerback", Role.CUSTOMER );
        service.save( u2 );
        final User u3 = createUser( "Devin Vann", "Linebacker", Role.CUSTOMER );
        service.save( u3 );

        Assertions.assertEquals( 3, service.count(), "There should be three users in the database" );

        service.delete( u2 );

        final List<User> dbUsers = service.findAll();

        Assertions.assertEquals( 2, service.count(), "There should be two users in the database." );

        for ( int i = 0; i < service.count(); i++ ) {
            Assertions.assertTrue( dbUsers.get( i ).equals( u1 ) || dbUsers.get( i ).equals( u3 ) );
        }

    }

    @Test
    @Transactional
    public void testDeleteUser_DatabaseInteraction3 () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Users in the CoffeeMaker" );

        // Delete the last item added.

        final User u1 = createUser( "Kendrick Raphael", "Running Back", Role.EMPLOYEE );
        service.save( u1 );
        final User u2 = createUser( "Ayden White", "Cornerback", Role.CUSTOMER );
        service.save( u2 );
        final User u3 = createUser( "Devin Vann", "Linebacker", Role.CUSTOMER );
        service.save( u3 );

        Assertions.assertEquals( 3, service.count(), "There should be three users in the database" );

        service.delete( u3 );

        final List<User> dbUsers = service.findAll();

        Assertions.assertEquals( 2, service.count(), "There should be two users in the database." );

        for ( int i = 0; i < service.count(); i++ ) {
            Assertions.assertTrue( dbUsers.get( i ).equals( u2 ) || dbUsers.get( i ).equals( u1 ) );
        }

    }

    @Test
    @Transactional
    public void testEditUser () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no User in the CoffeeMaker" );

        final User u1 = createUser( "Jordan Houston", "Running Back", Role.EMPLOYEE );
        service.save( u1 );

        u1.setPassword( "Redshirt" );

        service.save( u1 );

        final User retrieved = service.findByName( "Jordan Houston" );

        Assertions.assertEquals( Role.EMPLOYEE, retrieved.getRole() );
        Assertions.assertEquals( 1, service.count(), "Editing a user shouldn't duplicate it" );

    }

    @Test
    @Transactional
    public void testUserEquals () {

        final User u1 = createUser( "Zamurai", "Plaintext Password", Role.CUSTOMER );

        final User u2 = createUser( "Zamurai", "Plaintext Password", Role.CUSTOMER );

        Assertions.assertTrue( u1.equals( u1 ) );

        Assertions.assertTrue( u1.equals( u2 ) );

        final User u3 = createUser( "Zamurai", "Plaintext Password", Role.EMPLOYEE );

        Assertions.assertFalse( u1.equals( u3 ) );

        Assertions.assertFalse( u3.equals( u1 ) );

        Assertions.assertFalse( u1.equals( null ) );
    }

    @Test
    @Transactional
    public void testToString () {
        final User u1 = createUser( "TestUser", "TestPassword", Role.EMPLOYEE );

        Assertions.assertTrue( u1.toString().contains( "TestUser" ) );
        Assertions.assertTrue( u1.toString().contains( "EMPLOYEE" ) );
        Assertions.assertFalse( u1.toString().contains( "TestPassword" ) );

    }

    private User createUser ( final String name, final String password, final Role role ) {
        final User u = new User();
        u.setName( name );
        u.setPassword( password );
        u.setRole( role );
        return u;
    }

}
