package edu.ncsu.csc.CoffeeMaker.api;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import edu.ncsu.csc.CoffeeMaker.WebSecurityConfig;
import edu.ncsu.csc.CoffeeMaker.models.Role;

public class APILogoutTest extends SecureAPITest {
    @Autowired
    private MockMvc mvc;

    /**
     * Can logged out users see the logout page?
     */
    @Test
    @Transactional
    public void testLogoutPage() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                .get(WebSecurityConfig.LOGOUT_PAGE)
                )
            .andExpect(MockMvcResultMatchers.status().isFound())
            .andExpect(MockMvcResultMatchers.redirectedUrl(WebSecurityConfig.LOGOUT_SUCCESS_URL));
    }

    /**
     * Can logged in users see the logout page?
     */
    @Test
    @Transactional
    @WithMockUser ( roles = AUTHORIZED_ROLE )
    public void testLogoutPageAuthorized() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                .get(WebSecurityConfig.LOGOUT_PAGE)
                )
            .andExpect(MockMvcResultMatchers.status().isFound())
            .andExpect(MockMvcResultMatchers.redirectedUrl(WebSecurityConfig.LOGOUT_SUCCESS_URL));
    }

    @Test
    @Transactional
    public void testLogout () throws Exception {
        APILoginTest.assert_role(null, mvc.perform(MockMvcRequestBuilders
                .post(WebSecurityConfig.LOGOUT_PAGE)
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                )
            .andExpect(MockMvcResultMatchers.status().isFound())
            .andExpect(MockMvcResultMatchers.redirectedUrl(WebSecurityConfig.LOGOUT_SUCCESS_URL))
            .andReturn());
    }

    @Test
    @Transactional
    @WithMockUser ( roles = Role.Roles.CUSTOMER )
    public void testLogoutAuthorized () throws Exception {
        testLogout();
    }
}
