package edu.ncsu.csc.CoffeeMaker.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;

import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.models.CoffeeOrder;
import edu.ncsu.csc.CoffeeMaker.models.User;
import edu.ncsu.csc.CoffeeMaker.services.CoffeeOrderService;

public class APIOrderTest extends SecureAPITest {

    @Autowired
    private CoffeeOrderService orderService;

    @BeforeEach
    public void setup () {
        orderService.deleteAll();
    }

    /**
     * @return a mocked user for testing
     */
    static User mockUser () {
        final User user = new User();
        user.setName( "TestUser" );
        user.setPassword( "TestPassword" );
        return user;
    }

    @Test
    @Transactional
    @WithMockUser ( roles = { "CUSTOMER" } )
    public void testPlaceOrderCustomer () throws Exception {
        orderService.deleteAll();

        final CoffeeOrder order = new CoffeeOrder();
        order.setDate( "1" );
        order.setFulfilled( false );

        mvc.perform( post( "/api/v1/customer/order/Mocha" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( mockUser().getName() ) ) ).andExpect( status().isOk() );

        Assertions.assertEquals( 1, orderService.count(), "There should be one order in the database" );
    }

    @Test
    @Transactional
    @WithMockUser ( roles = { "EMPLOYEE" } )
    public void testUpdateFulfilledStatus () throws Exception {
        orderService.deleteAll();

        final CoffeeOrder order1 = new CoffeeOrder();
        order1.setDate( "1" );
        order1.setFulfilled( false );

        final CoffeeOrder order2 = new CoffeeOrder();
        order2.setDate( "2" );
        order2.setFulfilled( false );

        orderService.save( order1 );
        orderService.save( order2 );

        final List<CoffeeOrder> ordersToUpdate = Arrays.asList( order1, order2 );

        for ( final CoffeeOrder order : ordersToUpdate ) {
            mvc.perform( put( "/api/v1/employee/order/fulfilled" ).contentType( MediaType.APPLICATION_JSON )
                    .content( TestUtils.asJsonString( order ) ) ).andExpect( status().isOk() );
        }

        final CoffeeOrder updatedOrder1 = orderService.findByDate( order1.getDate() );
        final CoffeeOrder updatedOrder2 = orderService.findByDate( order2.getDate() );

        Assertions.assertTrue( updatedOrder1.isFulfilled(), "Order 1 should be marked as fulfilled" );
        Assertions.assertTrue( updatedOrder2.isFulfilled(), "Order 2 should be marked as fulfilled" );
    }

    @Test
    @Transactional
    @WithMockUser ( roles = { "EMPLOYEE" } )
    public void testUpdateFulfilledStatusNonexistentOrder () throws Exception {
        orderService.deleteAll();

        final CoffeeOrder order = new CoffeeOrder();
        order.setDate( "1" );
        order.setFulfilled( false );

        mvc.perform( put( "/api/v1/employee/order/fulfilled" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( order ) ) ).andExpect( status().isOk() );

        // Since the order doesn't exist, it shouldn't be marked as fulfilled,
        // and there
        // should be no errors
        final CoffeeOrder updatedOrder = orderService.findByDate( order.getDate() );
        Assertions.assertNull( updatedOrder );
    }

    @Test
    @Transactional
    @WithMockUser ( roles = { "CUSTOMER" } )
    public void testUpdatePickedUpStatus () throws Exception {
        orderService.deleteAll();

        final CoffeeOrder order1 = new CoffeeOrder();
        order1.setDate( "1" );
        order1.setPickedUp( false );

        orderService.save( order1 );

        mvc.perform( put( "/api/v1/customer/order/pickedUp" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( order1 ) ) ).andExpect( status().isOk() );

        final CoffeeOrder updatedOrder1 = orderService.findByDate( order1.getDate() );

        Assertions.assertTrue( updatedOrder1.isPickedUp(), "Order 1 should be marked as fulfilled" );
    }

    @Test
    @Transactional
    @WithMockUser ( roles = { "CUSTOMER" } )
    public void testUpdatePickedUpStatusNonexistentOrder () throws Exception {
        orderService.deleteAll();

        final CoffeeOrder order = new CoffeeOrder();
        order.setDate( "1" );
        order.setPickedUp( false );

        mvc.perform( put( "/api/v1/customer/order/pickedUp" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( order ) ) ).andExpect( status().isOk() );

        // Since the order doesn't exist, it shouldn't be marked as fulfilled,
        // and there
        // should be no errors
        final CoffeeOrder updatedOrder = orderService.findByDate( order.getDate() );
        Assertions.assertNull( updatedOrder );
    }

    @Test
    @WithMockUser ( roles = { "EMPLOYEE" } )
    public void testGetOrderAsEmployee () throws Exception {
        orderService.deleteAll();

        final CoffeeOrder order = new CoffeeOrder();
        order.setDate( "1" );
        order.setFulfilled( false );
        orderService.save( order );

        final String result = mvc.perform( get( "/api/v1/employee/order" ) ).andExpect( status().isOk() ).andReturn()
                .getResponse().getContentAsString();

        Assertions.assertTrue( result.contains( "1" ), "Response should contain order display ID" );
        Assertions.assertTrue( result.contains( "false" ), "Response should contain order fulfillment status" );
    }

    @Test
    @WithMockUser ( roles = { "CUSTOMER" } )
    public void testGetOrderAsCustomer () throws Exception {
        orderService.deleteAll();

        final CoffeeOrder order = new CoffeeOrder();
        order.setDate( "1" );
        order.setFulfilled( false );
        orderService.save( order );

        final String result = mvc.perform( get( "/api/v1/customer/order" ) ).andExpect( status().isOk() ).andReturn()
                .getResponse().getContentAsString();

        Assertions.assertTrue( result.contains( "1" ), "Response should contain order display ID" );
        Assertions.assertTrue( result.contains( "false" ), "Response should contain order fulfillment status" );
    }
}
