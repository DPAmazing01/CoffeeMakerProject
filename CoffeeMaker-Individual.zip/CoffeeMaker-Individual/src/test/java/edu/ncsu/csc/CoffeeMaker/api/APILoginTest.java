package edu.ncsu.csc.CoffeeMaker.api;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import edu.ncsu.csc.CoffeeMaker.controllers.APIController;
import edu.ncsu.csc.CoffeeMaker.controllers.APILoginController;
import edu.ncsu.csc.CoffeeMaker.models.Role;
import edu.ncsu.csc.CoffeeMaker.models.User;
import edu.ncsu.csc.CoffeeMaker.controllers.MappingController;
import edu.ncsu.csc.CoffeeMaker.services.UserService;

public class APILoginTest extends SecureAPITest {
    @Autowired
    private MockMvc mvc;

    @Autowired
    private UserService userService;

    /*
     * Performs a get request to a protected test endpoint which doesn't exist
     * to trigger a 404 error but only for logged in users - see tests for
     * examples
     */
    private ResultActions performProtectedNotFound () throws Exception {
        return mvc.perform( MockMvcRequestBuilders.get( APIController.CUSTOMER_PATH + "does not exist" ) );
    }

    /** A random role which is not authorized to view the protected page */
    private static final String UNAUTHORIZED_ROLE = "bad role";

    /**
     * A user who is not logged in should be redirected to the login page
     */
    @Test
    @Transactional
    public void testProtectedUnknown () throws Exception {
        performProtectedNotFound().andExpect( MockMvcResultMatchers.status().isFound() )
                .andExpect( MockMvcResultMatchers.redirectedUrl( "http://localhost" + MappingController.LOGIN_PAGE ) );
    }

    /**
     * A user who is logged in but not authorized should be given a forbidden
     * error
     */
    @Test
    @Transactional
    @WithMockUser ( roles = UNAUTHORIZED_ROLE )
    public void testProtectedUnauthorized () throws Exception {
        performProtectedNotFound().andExpect( MockMvcResultMatchers.status().isForbidden() );
    }

    /**
     * A user who is logged in and authorized should be given a not found,
     * because this test page doesn't actually exist
     */
    @Test
    @Transactional
    @WithMockUser ( roles = Role.Roles.CUSTOMER )
    public void testProtectedAuthorized () throws Exception {
        performProtectedNotFound().andExpect( MockMvcResultMatchers.status().isNotFound() );
    }

    /**
     * Login page tests
     */

    /**
     * Can not logged in users view the login page?
     */
    @Test
    @Transactional
    public void testLoginPage () throws Exception {
        mvc.perform( MockMvcRequestBuilders.get( MappingController.LOGIN_PAGE ) ).andExpect( MockMvcResultMatchers.status().isOk() );
    }

    /**
     * Can logged in users view the login page?
     */
    @Test
    @Transactional
    @WithMockUser ( roles = Role.Roles.CUSTOMER )
    public void testLoginPageAuthorized () throws Exception {
        testLoginPage();
    }

    /**
     * Performs a login with the given credentials
     */
    ResultActions perform_login(String username, String password) throws Exception {
        return mvc.perform(MockMvcRequestBuilders
                .post(MappingController.LOGIN_PAGE)
                .content(String.format("username=%s&password=%s", username, password))
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                );
    }

    static User getMockUser() {
        // make a user to log in as
        User user = new User();
        user.setName("username");
        user.setRole(Role.CUSTOMER);
        user.setPassword("password");
        return user;
    }

    /**
     * Extracts a role from an MvcResult, and checks that it matches a given role
     * @param expected the role we are expecting, or null to expect no roles
     */
    static org.springframework.security.core.userdetails.User assert_role(Role expected, MvcResult result) {
        HttpSession session = result.getRequest().getSession();
        Assertions.assertNotNull(session);
        Object object = session.getAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY);
        if (expected == null) {
            Assertions.assertNull(object, "expecting no role, should not have had any security context");
            return null;
        }

        Assertions.assertNotNull(object, "expecting " + expected + ", should have had security context");
        Assertions.assertTrue(object instanceof SecurityContext, "expecting " + expected + ", expected a security context instance");
        SecurityContext securityContext = (SecurityContext) object;
        Authentication authentication = securityContext.getAuthentication();
        Assertions.assertNotNull(authentication);
        Assertions.assertEquals(1, authentication.getAuthorities().size(), "expecting " + expected + ", there should only be one role");
        Assertions.assertEquals("ROLE_" + expected, authentication.getAuthorities().iterator().next().getAuthority());
        Object principalObject = authentication.getPrincipal();
        Assertions.assertTrue(principalObject instanceof org.springframework.security.core.userdetails.User, "expected " + expected + ", expected authentication to have Spring userdetails.User principal");
        return (org.springframework.security.core.userdetails.User) principalObject;
    }

    void assert_no_role(MvcResult result) {
        Assertions.assertNull(assert_role(null, result));
    }

    /**
     * Can not logged in users log in?
     */
    @Test
    @Transactional
    public void testLogin () throws Exception {
        String password = "testpassword";
        User user = userService.registerUser("testuser", password, Role.CUSTOMER);
        Assertions.assertNotNull(user);

        // try to log in
        org.springframework.security.core.userdetails.User springUser =
            assert_role(user.getRole(), perform_login(user.getName(), password)
                    .andExpect(MockMvcResultMatchers.status().isFound())
                    .andExpect(MockMvcResultMatchers.redirectedUrl(APILoginController.LOGIN_SUCCESS_URL))
                    .andReturn());
        Assertions.assertEquals(user.getName(), springUser.getUsername(), "expected spring user username to match our user");
    }

    /**
     * Can not logged in users not log in with bad credentials?
     */
    @Test
    @Transactional
    public void testLoginBadCredentials () throws Exception {
        User user = userService.registerUser("testuser", "testpassword", Role.CUSTOMER);
        Assertions.assertNotNull(user);

        assert_no_role(perform_login("invalidusername", "invalidpassword")
                .andExpect(MockMvcResultMatchers.status().isFound())
                .andExpect(MockMvcResultMatchers.redirectedUrl(APILoginController.LOGIN_FAIL_URL))
                .andReturn()
                );
        assert_no_role(perform_login(user.getName(), "invalidpassword")
                .andExpect(MockMvcResultMatchers.status().isFound())
                .andExpect(MockMvcResultMatchers.redirectedUrl(APILoginController.LOGIN_FAIL_URL))
                .andReturn()
                );
    }

    /**
     * Can logged in users log in?
     */
    @Test
    @Transactional
    @WithMockUser ( roles = AUTHORIZED_ROLE )
    public void testLoginAuthorized () throws Exception {
        testLogin();
    }

    /**
     * Can not logged in users log in as guest?
     */
    @Test
    @Transactional
    public void testLoginGuest () throws Exception {
        int oldSize = userService.findAll().size();

        Role guestRole = Role.GUEST;
        org.springframework.security.core.userdetails.User springUser = 
            assert_role(guestRole, mvc.perform(MockMvcRequestBuilders
                        .post(APILoginController.GUEST_LOGIN_ENDPOINT)
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        )
                    .andExpect(MockMvcResultMatchers.status().isFound())
                    .andExpect(MockMvcResultMatchers.redirectedUrl(APILoginController.LOGIN_SUCCESS_URL))
                    .andReturn());

        // check that a new user was created
        Assertions.assertEquals(oldSize + 1, userService.findAll().size());

        // check to make sure the new user is a guest
        User user = userService.findByName(springUser.getUsername());
        Assertions.assertEquals(user.getRole(), guestRole);
    }

    /**
     * Can logged in users log in as guest?
     */
    @Test
    @Transactional
    @WithMockUser ( roles = AUTHORIZED_ROLE )
    public void testLoginGuestAuthorized () throws Exception {
        // todo security
        /*
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();
        Assertions.assertNotNull(authentication);*/
        testLoginGuest();
        //Assertions.assertNotNull(authentication);
    }
}
