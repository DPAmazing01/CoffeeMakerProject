package edu.ncsu.csc.CoffeeMaker.unit;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import edu.ncsu.csc.CoffeeMaker.SetupDataLoader;
import edu.ncsu.csc.CoffeeMaker.TestConfig;
import edu.ncsu.csc.CoffeeMaker.models.User;
import edu.ncsu.csc.CoffeeMaker.repositories.UserRepository;

@ExtendWith ( SpringExtension.class )
@EnableAutoConfiguration
@SpringBootTest ( classes = TestConfig.class )
public class ManagerTest {
    @Autowired
    private UserRepository userRepository;

    @Test
    public void testHasManager () {
        final User user = userRepository.findByName(SetupDataLoader.MANAGER_USERNAME);
        Assertions.assertNotNull(user, "manager with username " + SetupDataLoader.MANAGER_USERNAME + " should exist");
        Assertions.assertEquals(SetupDataLoader.MANAGER_ROLE, user.getRole());
    }
}
