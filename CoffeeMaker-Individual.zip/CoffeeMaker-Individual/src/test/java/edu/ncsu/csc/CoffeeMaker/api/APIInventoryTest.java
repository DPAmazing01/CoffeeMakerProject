package edu.ncsu.csc.CoffeeMaker.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.test.context.support.WithMockUser;

import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Inventory;
import edu.ncsu.csc.CoffeeMaker.models.Role;
import edu.ncsu.csc.CoffeeMaker.services.IngredientService;
import edu.ncsu.csc.CoffeeMaker.services.InventoryService;

public class APIInventoryTest extends SecureAPITest {
    @Autowired
    private IngredientService     service;

    @Autowired
    private InventoryService      inventoryService;

    /**
     * Sets up the tests.
     */
    @BeforeEach
    public void setup () {
        service.deleteAll();

        final Inventory ivt = inventoryService.getInventory();

        final Ingredient i1 = new Ingredient( "Coffee", 500 );
        final Ingredient i2 = new Ingredient( "Milk", 500 );
        final Ingredient i3 = new Ingredient( "Sugar", 500 );
        final Ingredient i4 = new Ingredient( "Chocolate", 500 );

        ivt.addIngredientToInventory( i1 );
        ivt.addIngredientToInventory( i2 );
        ivt.addIngredientToInventory( i3 );
        ivt.addIngredientToInventory( i4 );

        inventoryService.save( ivt );
    }

    /**
     * Create a valid ingredient and POST it, ensuring the correct HTTP response
     * is returned.
     *
     * @throws Exception
     * @throws UnsupportedEncodingException
     */
    @Test
    @Transactional
    @WithMockUser ( roles = { Role.Roles.MANAGER } )
    public void testGetInventory () throws UnsupportedEncodingException, Exception {

        final Inventory ivt = inventoryService.getInventory();
        final ArrayList<Ingredient> newInt = new ArrayList<Ingredient>();

        final String inv = mvc.perform( get( "/api/v1/manager/inventory" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        Assertions.assertTrue( inv.contains( "Coffee" ) );
        Assertions.assertTrue( inv.contains( "Milk" ) );
        Assertions.assertTrue( inv.contains( "Sugar" ) );
        Assertions.assertTrue( inv.contains( "Chocolate" ) );
        Assertions.assertFalse( inv.contains( "Trash" ) );
    }

}
